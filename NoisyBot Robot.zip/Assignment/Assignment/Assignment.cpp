#include <Windows.h>
#include <Windowsx.h>
#include <gl/GL.h>
#include <math.h>
#include <gl/GLU.h>
#include <string>
using namespace std;

#pragma comment (lib, "OpenGL32.lib")

#define WINDOW_TITLE "OpenGL Window"

#pragma region defination
// VK_A - VK_Z are the same as ASCII 'A' - 'Z' (0x41 - 0x5A)
#define VK_A 0x41
#define VK_B 0x42
#define VK_C 0x43
#define VK_D 0x44
#define VK_E 0x45
#define VK_F 0x46
#define VK_G 0x47
#define VK_H 0x48
#define VK_I 0x49
#define VK_J 0x4A
#define VK_K 0x4B
#define VK_L 0x4C
#define VK_M 0x4D
#define VK_N 0x4E
#define VK_O 0x4F
#define VK_P 0x50
#define VK_Q 0x51
#define VK_R 0x52
#define VK_S 0x53
#define VK_T 0x54
#define VK_U 0x55
#define VK_V 0x56
#define VK_W 0x57
#define VK_X 0x58
#define VK_Y 0x59
#define VK_Z 0x5A

//VK_0 - VK_9 are the same as ASCII '0' - '9' (0x30 - 0x39)
#define VK_0 0x30
#define VK_1 0x31
#define VK_2 0x32
#define VK_3 0x33
#define VK_4 0x34
#define VK_5 0x35
#define VK_6 0x36
#define VK_7 0x37
#define VK_8 0x38
#define VK_9 0x39
#pragma endregion
//environment
bool dayOn = false;
bool dayOff = false;
void drawSea(GLUquadricObj* object);
void drawSky(GLUquadricObj* object);

//Drawing parts functions
float rotateRightHand = 0;
float rotateHead = 0;
float rotateBody = 0;
float rotateLowerBody = 0;
bool isMovingHead = false;
bool isMovingBody = false;
bool isMovingLowerBody = false;
void drawHat(GLUquadricObj* object);
void drawHead(GLUquadricObj* object);
void drawFace(GLUquadricObj* object);
void drawNeck(GLUquadricObj* object);
void drawArmorPlate();
void drawBody(GLUquadricObj* object);
void drawArmor(GLUquadricObj* object);
void drawReactor(GLUquadricObj* object);
void drawKatana(GLUquadricObj* object);
void drawKatanaCover(GLUquadricObj* object);
void drawCyberBot(GLUquadricObj* object);
void drawSM(GLUquadricObj* object);
void drawBallJoint(GLUquadricObj* object);

//laser
string str;
int textureType = 1;
GLuint assetTexture[2];
void drawLaserWeapon(GLUquadricObj* object);
void drawUpperPartTurret(GLUquadricObj* object);
void drawMiddlePartTurret(GLUquadricObj* object);
void drawDownPartTurret(GLUquadricObj* object);
void drawWeapon(GLUquadricObj* object);

//katana
void drawKatanaWeapon(GLUquadricObj* object);

//hand animation variable + Laser
float initialArmRotate = 0.0f;
float initialArmRotate1 = 0.0f;
float armRotate = 0.0f;
float armRotate1 = 0.0f;
float initialArmMove = 0.0f;
float initialArmMove1 = 0.0f;
float armMove = 0.0f;
float armMove1 = 0.0f;
float initialFingerMove = 0.0f;
float fingerMove = 0.0f;
float initialThumbMove = 0.0f;
float thumbMove = 0.0f;
float bodyAngle = 0.0f;
float laserRange = 0.0f;
float speed = 1.5f;
bool isShield = false;
bool isWeaponOn = false;
bool isMovingArm = false;
bool isShooting = false;
bool readyShooting = false;
bool readyKatana = false;
bool readyKatanaCover = true;
float translateT = -0.05f;
float initialLeftArmSpeed = 0.0f, leftArmSpeed = 0.0f, leftArmMaxAngle = 0.0f, leftArmMinAngle = 0.0f;
float initialRightArmSpeed = 0.0f, rightArmSpeed = 0.0f, rightArmMaxAngle = 0.0f, rightArmMinAngle = 0.0f;
void drawRec(float minX, float maxX, float minY, float maxY, float minZ, float maxZ, GLenum type);
void drawLeftHand();
void drawRightHand();
void adjustFingerMove(float tx, float ty, float tz, float rx, float ry, float rz, float maxA, float minA);
void shieldPentagon(float minZ, float maxZ, GLenum type1, GLenum type2);
void DrawShield();
void DrawHandle();
void controlShield();

//leg
void drawFillSphere(double radius);
void drawFillCylinder(double baseRadius, double topRadius, double height, int texture);
void drawCuboid(float length, float height, float width);
void drawRightAngleTriangle(float length, float height, float width);
void drawCubeLine(float length, float height, float width, float lineWidth);
//draw lower body + leg
boolean walking = false;
boolean rightLegForward = true;
float leftWalkingHipsAndThighAngle = 0.0;
float leftWalkingThighAndCalfAngle = 0.0;
float rightWalkingHipsAndThighAngle = 0.0;
float rightWalkingThighAndCalfAngle = 0.0;
float walkFrontAngle = 0.0;
boolean running = false;
boolean runningRightLegForward = true;
float leftRunningHipsAndThighAngle = 0.0;
float leftRunningThighAndCalfAngle = 0.0;
float rightRunningHipsAndThighAngle = 0.0;
float rightRunningThighAndCalfAngle = 0.0;
float runFrontAngle = 0.0;
boolean flying = false;
float flyAngleY = 0.0;
float flyAngleZ = 0.0;
float flyingHipsAndThighAngle = 0.0;
float flyingThighAndCalfAngle = 0.0;
float flyingCylinderHeight = 0.0;
float flyingFireHeight = 0.0;
void drawLowerBody(GLUquadricObj* object);
void walk();
void walkingFront();
void run();
void runningFront();
void fly();
void fire();
void drawPelvis(GLUquadricObj* object);
void drawLeftLeg();
void drawRightLeg();
void drawJointHipsToThigh();
void drawThigh();
void drawJointThighToCalf();
void drawCalf();
void drawJointCalfToFoot();
void drawFootL();
void drawFootR();
void drawFootArmor();
void drawFireUnderFoot();

//lighting
GLfloat red[4] = { 1,0,0,1 };
GLfloat crimsonRed[4] = { 153 / 255.0f,0,0,1 };
GLfloat green[4] = { 0,1,0,1 };
GLfloat blue[4] = { 0,0,1,1 };
GLfloat black[4] = { 0,0,0,1 };
GLfloat gray[4] = { (float)192 / 255.0f,(float)192 / 255.0f,(float)192 / 255.0f,1 };
GLfloat gold[4] = { (float)212 / 255.0f, (float)175 / 255.0f, (float)55 / 255.0f ,1 };
GLfloat ambientLight[4] = { 1,1,1,1 };
GLfloat diffuseLight[4] = { 1,1,1,1 };
GLfloat specularLight[4] = { 1,1,1,1 };
GLfloat positionLight[3] = { 1,1,1 };
GLfloat positionLight0[4] = { 0,1,0,0 };
boolean isLighting = true;
bool lightOn = false;
float moveL = 2.0f;
void lighting();
void redMaterial();
void whiteMaterial();
void grayMaterial();
void goldMaterial();

//texture
bool textureOn = false;
BITMAP BMP;
HBITMAP hBMP = NULL;
GLuint grayMetalTextures, katanaBladeTextures, katanaHandlerTextures, goldMetalTextures, moonTextures, whiteTextures, flameTextures, sunTextures;
GLuint umbrellaTextures, blackMetalTextures, armorPlateTextures, armorPlateSideTextures, BodyTextures, whiteMetalTextures, seaTextures, skyTextures, nightSeaTextures, nightSkyTextures;

//mouse movement
float zoomLevel = -7.0f;
float lastX = 0.0f, lastY = 0.0f;
float xRotated = 1.0f, yRotated = 1.0f, zRotated = -30.0f;
float rotateReactor = 0.0f;
float ZWspeed = 0.5f;
float time = 0;
boolean isActive = true;

LRESULT WINAPI WindowProcedure(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		break;

		//mouse
	case WM_MOUSEMOVE:
		switch (wParam) {
		case MK_LBUTTON:
			int xPos = GET_X_LPARAM(lParam);
			int yPos = GET_Y_LPARAM(lParam);
			zRotated += xPos - lastX;
			xRotated += yPos - lastY;
			lastX = xPos;
			lastY = yPos;
			break;
		}
		break;

	case WM_LBUTTONDOWN:
		lastX = GET_X_LPARAM(lParam);
		lastY = GET_Y_LPARAM(lParam);
		break;

	case WM_MOUSEWHEEL:
		zoomLevel += GET_WHEEL_DELTA_WPARAM(wParam) / 120.0f;
		break;

		//keyboard------------------------------------------------------------
	case WM_KEYDOWN:
		if (wParam == VK_ESCAPE) {
			PostQuitMessage(0);
			break;
		}
		//8+9 = DayNight-----------------------------------------------------
		else if (wParam == 0x38) {
			dayOff = !dayOff;
		}
		else if (wParam == 0x39) {
			if (dayOff == true) {
				dayOn = !dayOn;
			}
		}
		//F/R/W=Fly or Walk or Run-------------------------------------------
				//W
		else if (wParam == 'M') {
			if (walking) {
				walking = false;
				rightLegForward = false;
			}
			else {
				walking = true;
				running = false;
				rightLegForward = true;
			}
		}			//WALKING 
		else if (wParam == 'N') {
			if (running) {
				running = false;
				runningRightLegForward = false;
			}
			else {
				running = true;
				walking = false;
				runningRightLegForward = true;
			}
		}			//RUNNING 
		else if (wParam == 'B') {
			flying = true;
			flyAngleY += 0.2;
			flyAngleZ -= 0.4;
		}
		//lighting----------------------------------------------------------
		if (wParam == VK_W) {
			positionLight[1] += moveL;
		}
		if (wParam == VK_S) {
			positionLight[1] -= moveL;
		}
		if (wParam == VK_A) {
			positionLight[0] -= moveL;
		}
		if (wParam == VK_D) {
			positionLight[0] += moveL;
		}
		if (wParam == VK_E) {
			positionLight[2] += moveL;
		}
		if (wParam == VK_Q) {
			positionLight[2] -= moveL;
		}
		//----------------------------------------------------------------------
		//'1' + 'L' = Laser Gun
		else if (wParam == 0x31) {
			readyShooting = !readyShooting;

		}
		else if (wParam == 'L')
		{
			if (readyShooting) {
				isShooting = true;
			}
		}
		//'2' + '3' = katana
		else if (wParam == 0x32) {
			readyKatana = !readyKatana;

		}
		else if (wParam == 0x33) {
			if (readyKatana) {
				readyKatanaCover = !readyKatanaCover;
			}
		}
		//'T' = To activate Texture
		else if (wParam == 'T') {
			textureOn = !textureOn;
		}
		//'Y' = To activate Lighting
		else if (wParam == 'Y') {
			lightOn = !lightOn;
		}
		//RESET SPACE----------------------------------------------
		if (wParam == VK_SPACE) {
			//hand
			initialArmRotate = 0.0f;
			initialArmRotate1 = 0.0f;
			armRotate = 0.0f;
			armRotate1 = 0.0f;
			initialArmMove = 0.0f;
			initialArmMove1 = 0.0f;
			armMove = 0.0f;
			armMove1 = 0.0f;
			initialFingerMove = 0.0f;
			fingerMove = 0.0f;
			initialThumbMove = 0.0f;
			thumbMove = 0.0f;
			leftArmMaxAngle = 0.0f;
			rightArmMaxAngle = 0.0f;

			//leg
			walking = false;
			rightLegForward = true;
			leftWalkingHipsAndThighAngle = 0.0;
			leftWalkingThighAndCalfAngle = 0.0;
			rightWalkingHipsAndThighAngle = 0.0;
			rightWalkingThighAndCalfAngle = 0.0;
			walkFrontAngle = 0.0;

			running = false;
			runningRightLegForward = true;
			leftRunningHipsAndThighAngle = 0.0;
			leftRunningThighAndCalfAngle = 0.0;
			rightRunningHipsAndThighAngle = 0.0;
			rightRunningThighAndCalfAngle = 0.0;
			runFrontAngle = 0.0;

			flying = false;
			flyAngleY = 0.0;
			flyAngleZ = 0.0;
			flyingHipsAndThighAngle = 0.0;
			flyingThighAndCalfAngle = 0.0;
			flyingCylinderHeight = 0.0;
			flyingFireHeight = 0.0;

			//zbody movement
			rotateBody = 0.0f;
			rotateHead = 0.0f;
			rotateLowerBody = 0.0f;

		}
		else if (wParam == 'H')
		{
			isMovingArm = !isMovingArm;
		}
		else if (wParam == 'A') {
			//AntiClockwise - L ARM
			if (isMovingArm)
				armRotate = -3.0f;
		}
		else if (wParam == 'D') {
			//Clockwise - L ARM
			if (isMovingArm)
				armRotate = 3.0f;
		}
		else if (wParam == 'W') {
			//AntiClockwise - L ARM
			if (isMovingArm)
				armMove = 3.0f;

		}
		else if (wParam == 'S') {
			//Clockwise - L ARM
			if (isMovingArm)
				armMove = -3.0f;
		}
		else if (wParam == VK_UP) {
			//AntiClockwise - R ARM
			if (isMovingArm)
				armMove1 = 3.0f;
		}
		else if (wParam == VK_DOWN) {
			//Clockwise - R ARM
			if (isMovingArm)
				armMove1 = -3.0f;
		}
		else if (wParam == VK_LEFT) {
			//AntiClockwise - R ARM
			if (isMovingArm)
				armRotate1 = 3.0f;
		}
		else if (wParam == VK_RIGHT) {
			//Clockwise - R ARM
			if (isMovingArm)
				armRotate1 = -3.0f;
		}
		//'C' - close hand
		else if (wParam == 'C') {
			if (isMovingArm)
			{
				fingerMove = 0.05f;
				thumbMove = 0.5f;
			}
		}
		//'O' - open hand
		else if (wParam == 'O') {
			if (isMovingArm)
			{
				fingerMove = -0.05f;
				thumbMove = -0.5f;
			}
		}
		else if (wParam == 'K') {// to left lower arm left right
			if (isMovingArm)
			{
				leftArmMaxAngle = 80.0f;
				if (initialLeftArmSpeed == 0.0f) {
					leftArmSpeed += speed;
				}
				if (initialLeftArmSpeed == leftArmMaxAngle) {
					leftArmSpeed -= speed;
				}
				rightArmSpeed -= speed;
			}
		}
		else if (wParam == 'P') {// to right lower arm left right
			if (isMovingArm)
			{
				rightArmMaxAngle = 80.0f;
				if (initialRightArmSpeed == 0.0f) {
					rightArmSpeed += speed;
				}
				if (initialRightArmSpeed == rightArmMaxAngle) {
					rightArmSpeed -= speed;
				}
				leftArmSpeed -= speed;
			}
		}//weapon
		else if (wParam == '2') {
			isWeaponOn = !isWeaponOn;
		}
		break;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}
//--------------------------------------------------------------------
bool initPixelFormat(HDC hdc)
{
	PIXELFORMATDESCRIPTOR pfd;
	ZeroMemory(&pfd, sizeof(PIXELFORMATDESCRIPTOR));

	pfd.cAlphaBits = 8;
	pfd.cColorBits = 32;
	pfd.cDepthBits = 24;
	pfd.cStencilBits = 0;

	pfd.dwFlags = PFD_DOUBLEBUFFER | PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW;

	pfd.iLayerType = PFD_MAIN_PLANE;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion = 1;

	// choose pixel format returns the number most similar pixel format available
	int n = ChoosePixelFormat(hdc, &pfd);

	// set pixel format returns whether it sucessfully set the pixel format
	if (SetPixelFormat(hdc, n, &pfd))
	{
		return true;
	}
	else
	{
		return false;
	}
}
//--------------------environament----------------------------------------
void drawSky(GLUquadricObj* object) {
	glPushMatrix(); {
		gluQuadricDrawStyle(object, GLU_FILL);
		grayMaterial();
		glColor3f((float)82 / 255, (float)109 / 255, (float)109 / 255);

		if (dayOn == false) {
			glBindTexture(GL_TEXTURE_2D, skyTextures);
		}
		else if (dayOn == true) {
			glBindTexture(GL_TEXTURE_2D, nightSkyTextures);
		}
		gluQuadricTexture(object, GL_TRUE);
		gluSphere(object, 15.0f, 100, 100);
	}
	glPopMatrix();
}
void drawSea(GLUquadricObj* object) {
	glPushMatrix(); {
		gluQuadricDrawStyle(object, GLU_FILL);
		grayMaterial();
		glColor3f((float)82 / 255, (float)109 / 255, (float)109 / 255);
		glTranslatef(0.0f, 0.0f, -2.5f);
		if (dayOn == false) {
			glBindTexture(GL_TEXTURE_2D, seaTextures);
		}
		else if (dayOn == true) {
			glBindTexture(GL_TEXTURE_2D, nightSeaTextures);
		}
		gluQuadricTexture(object, GL_TRUE);
		gluDisk(object, 0.0f, 20.0f, 20, 20);
	}
	glPopMatrix();
}
void drawSM(GLUquadricObj* object) {
	grayMaterial();
	glPushMatrix();
	glTranslatef(0, 0, 8.0f);
	gluQuadricDrawStyle(object, GLU_FILL);
	if (dayOn == false) {
		glBindTexture(GL_TEXTURE_2D, sunTextures);
	}
	else if (dayOn == true) {
		glBindTexture(GL_TEXTURE_2D, moonTextures);
	}
	gluQuadricTexture(object, GL_TRUE);
	gluSphere(object, 1.0f, 100, 100);
	glPopMatrix();
}
//---------------------BALL JOINT------------------------------------
void drawBallJoint(GLUquadricObj* object) {
	glPushMatrix(); {
		glTranslatef(0, 0.6f, 0.5f);
		glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
		gluSphere(object, 0.1, 100, 100);
		//left
		glPushMatrix(); {

			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glTranslatef(0.1f, 0, 0);
			glRotatef(90, 0, 1, 0);
			glPushAttrib(1);
			//crimson red
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			gluDisk(object, 0.08, 0.13, 100, 100);
			glPopAttrib();
		}glPopMatrix();

		//right
		glPushMatrix(); {
			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glTranslatef(-0.1f, 0, 0);
			glRotatef(90, 0, 1, 0);
			glPushAttrib(1);
			//crimson red
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			gluDisk(object, 0.08, 0.13, 100, 100);
			glPopAttrib();
		}glPopMatrix();

		glPushMatrix(); {
			glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
			glTranslatef(-0.1f, 0, 0);
			glRotatef(90, 0, 1, 0);
			glPushAttrib(1);
			//grey bar
			glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
			gluCylinder(object, 0.13, 0.13, 0.2, 100, 100);
			glPopAttrib();
		}glPopMatrix();
	}glPopMatrix();
}
//----------------------WEAPON(D)---------------------------------------- 
void drawLaserWeapon(GLUquadricObj* object) {
	//lazer
	time += 0.1f;
	if (isShooting)
	{
		laserRange += 0.5f;
	}
	if (laserRange > 20)
	{
		laserRange = 0;
		isShooting = false;

	}
	if (readyShooting) {
		//drawLeftTurret(object);
		drawWeapon(object);
	}
}
void drawUpperPartTurret(GLUquadricObj* object) {
	//left turrent
	glPushMatrix(); {
		glTranslatef(0.35f, 0, 0.2f);
		//upper part
		glPushMatrix(); {
			glRotatef(-15, 0, 1, 0);
			//shoot lazer position
			glPushMatrix(); {
				if (isShooting)
				{
					glTranslatef(0, -0.8f, 0);
					glPushMatrix();
					glTranslatef(0, 0, laserRange);
					glPushAttrib(1);
					glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
					glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
					gluCylinder(object, 0.05, 0.05, 0.7, 100, 100);
					glPopAttrib();
					glPopMatrix();
				}
			}glPopMatrix();

			//gun turrent
			glPushMatrix(); {
				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				glTranslatef(0, -0.8f, 0);
				glScalef(1, 1.5, 1);
				glPushAttrib(1);
				//crimson red
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				//front
				glBegin(GL_POLYGON);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.3f, 0.05f, 0.0f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.3f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.1f, 0.0f);
				glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, -0.1f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.3f, 0.05f, 0.0f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.3f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.1f, 0.0f);
				glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.0f, -0.1f, 0.0f);
				glEnd();

				//back
				glBegin(GL_POLYGON);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.1f, 1.5f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, 0.1f, 1.5f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.3f, 0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.3f, -0.05f, 1.5f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.1f, 1.5f);
				glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, -0.1f, 1.5f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.1f, 1.5f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, 0.1f, 1.5f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.3f, 0.05f, 1.5f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.3f, -0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.1f, -0.1f, 1.5f);
				glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.0f, -0.1f, 1.5f);
				glEnd();

				//side
				//right
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.3f, 0.05f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.3f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.3f, -0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.3f, 0.05f, 1.5f);
				glEnd();

				//up
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.1f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.0f, 0.1f, 1.5f);
				glEnd();

				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, 0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.3f, 0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.3f, 0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.1f, 0.1f, 1.5f);
				glEnd();

				//down
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.1f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.0f, -0.1f, 1.5f);
				glEnd();

				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, -0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(0.3f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.3f, -0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.1f, -0.1f, 1.5f);
				glEnd();

				//side
				//left
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.3f, 0.05f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.3f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.3f, -0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.3f, 0.05f, 1.5f);
				glEnd();

				//up
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.1f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.0f, 0.1f, 1.5f);
				glEnd();

				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, 0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.3f, 0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.3f, 0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.1f, 0.1f, 1.5f);
				glEnd();

				//down
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.1f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.0f, -0.1f, 1.5f);
				glEnd();

				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, -0.1f, 0.0f);
				glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.3f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.3f, -0.05f, 1.5f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.1f, -0.1f, 1.5f);
				glEnd();
				glPopAttrib();

			}glPopMatrix();

			//gun turrent cup
			glPushMatrix(); {
				glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
				glTranslatef(0, -0.8f, 0);
				glTranslatef(0.0f, 0.2f, 0.5f);
				glRotatef(90, 1, 0, 0);
				glPushAttrib(1);
				glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
				gluQuadricDrawStyle(object, GLU_FILL);
				gluCylinder(object, 0.1, 0.12, 0.05, 100, 100);
				glPopAttrib();
			}glPopMatrix();

			//gun turrent aim hole
			glPushMatrix(); {
				glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
				glTranslatef(0, -0.8f, 0);
				glPushAttrib(1);
				//green
				glColor3f(26 / 255.0f, 163 / 255.0f, 109 / 255.0f);
				gluCylinder(object, 0.1, 0.1, 1.7, 100, 100);
				glPopAttrib();
				glPushMatrix(); {
					glTranslatef(0, 0, 1.7f);
					glPushAttrib(1);
					//grey bar
					glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
					gluDisk(object, 0.05, 0.1, 100, 100);
					glPopAttrib();
				}glPopMatrix();
			}glPopMatrix();
		}glPopMatrix();
	}glPopMatrix();
}
void drawMiddlePartTurret(GLUquadricObj* object) {
	glPushMatrix(); {
		glTranslatef(0.35f, 0, 0.2f);
		//middle part
		glPushMatrix(); {
			glRotatef(-15, 0, 1, 0);
			//turrent up stand
			glPushMatrix(); {
				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				glTranslatef(0, -0.1f, 0.5f);
				glRotatef(90, 1, 0, 0);
				gluQuadricDrawStyle(object, GLU_FILL);
				gluCylinder(object, 0.1, 0.1, 0.6, 100, 100);
			}glPopMatrix();

			//turrent up ball joint
			glPushMatrix(); {
				glTranslatef(0, -0.6f, 0);
				drawBallJoint(object);
			}glPopMatrix();

			//turrent middle stand
			glPushMatrix(); {
				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				glTranslatef(0, 1.3f, 0.5f);
				glRotatef(90, 1, 0, 0);
				gluQuadricDrawStyle(object, GLU_FILL);
				gluCylinder(object, 0.1, 0.1, 1.3, 100, 100);
			}glPopMatrix();
		}glPopMatrix();
	}glPopMatrix();
}
void drawDownPartTurret(GLUquadricObj* object) {
	glPushMatrix(); {
		glTranslatef(0.35f, 0, 0.2f);
		//down part
		glPushMatrix(); {
			glRotatef(-15, 0, 1, 0);
			//turrent middle ball joint
			glPushMatrix(); {
				glTranslatef(0, 0.8f, 0);
				drawBallJoint(object);
			}glPopMatrix();
			//turrent down stand
			glPushMatrix(); {
				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				glTranslatef(0, 1.4f, 0.5f);
				gluQuadricDrawStyle(object, GLU_FILL);
				gluCylinder(object, 0.1, 0.1, 0.9, 100, 100);
			}glPopMatrix();
		}glPopMatrix();
	}glPopMatrix();
	//left turrent cup connect back
	glPushMatrix(); {
		glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
		//glRotatef(90, 1, 0, 0);
		glTranslatef(0, 1.4f, 1.4f);
		gluCylinder(object, 0.1, 0.15, 0.1, 100, 100);
	}glPopMatrix();
}
void drawWeapon(GLUquadricObj* object) {
	glPushMatrix(); {
		glRotatef(rotateBody, 0, 1, 0);
		drawUpperPartTurret(object);
		drawMiddlePartTurret(object);
		drawDownPartTurret(object);
	}glPopMatrix();
}
void drawKatanaWeapon(GLUquadricObj* object) {
	if (readyKatana == true) {
		glPushMatrix(); {
			glRotatef(rotateBody, 0, 0, 1);
			glScalef(0.6f, 0.6f, 0.6f);
			//katana #1
			glPushMatrix(); {
				glTranslatef(-1.5f, 0.5f, -2.3f);
				glRotatef(45, 0, 1, 0);
				glRotatef(90, 0, 0, 1);
				glScalef(0.5f, 0.5f, 0.5f);
				drawKatana(object);
			}glPopMatrix();

			//katana #2
			glPushMatrix(); {
				glTranslatef(1.5f, 0.5f, -2.3f);
				glRotatef(-45, 0, 1, 0);
				glRotatef(-90, 0, 0, 1);
				glScalef(0.5f, 0.5f, 0.5f);
				drawKatana(object);
			}glPopMatrix();

			if (readyKatanaCover == true) {
				//remove katana cover #1
				glPushMatrix(); {
					glTranslatef(-1.5f, 0.5f, -2.3f);
					glRotatef(45, 0, 1, 0);
					glRotatef(90, 0, 0, 1);
					glScalef(0.5f, 0.5f, 0.5f);
					drawKatanaCover(object);
				}glPopMatrix();

				//remove katana cover #2
				glPushMatrix(); {
					glTranslatef(1.5f, 0.5f, -2.3f);
					glRotatef(-45, 0, 1, 0);
					glRotatef(-90, 0, 0, 1);
					glScalef(0.5f, 0.5f, 0.5f);
					drawKatanaCover(object);
				}glPopMatrix();
			}
		}glPopMatrix();
	}
}
//-----------------BODY--------------------------------------
void drawCyberBot(GLUquadricObj* object) {

	glPushMatrix(); {
		glScalef(0.3f, 0.3f, 0.3f);
		gluQuadricTexture(object, GL_TRUE);

		//head
		glPushMatrix(); {
			glRotatef(rotateHead, 0, 0, 1);
			if (rotateHead >= 20) {
				rotateHead = 20;
			}
			if (rotateHead <= -20) {
				rotateHead = -20;
			}
			//hat	
			glPushMatrix(); {
				glTranslatef(0, -.5f, 0.85f);
				glRotatef(-90, 1, 0, 0);
				drawHat(object);
			}glPopMatrix();

			//head
			glPushMatrix(); {
				glTranslatef(0, -.5f, 0.85f);
				glRotatef(-90, 1, 0, 0);
				drawHead(object);
				drawFace(object);
				drawNeck(object);
			}glPopMatrix();
		}glPopMatrix();

		//body + hand
		glPushMatrix(); {
			glRotatef(rotateBody, 0, 0, 1);

			//body
			glPushMatrix(); {
				drawBody(object);
				drawArmor(object);
				drawReactor(object);
			}glPopMatrix();

			//wee harn
			//hand
			glPushMatrix(); {
				glScalef(3, 3, 3);
				glTranslatef(0, -0.1f, -0.5f);
				glRotatef(90, 1, 0, 0);
				glRotatef(180, 0, 1, 0);
				drawLeftHand();
				drawRightHand();
			}glPopMatrix();
		}glPopMatrix();

		//leg
		glPushMatrix(); {
			glRotatef(rotateLowerBody, 0, 0, 1);
			glPushMatrix(); {
				glTranslatef(0, 0, 1);
				glScalef(0.6, 0.6, 0.6);
				glTranslatef(-0.25f, -0.8f, -9.0f);
				drawLowerBody(object);
			} glPopMatrix();
		}glPopMatrix();
	}glPopMatrix();
}
void drawArmorPlate() {
	redMaterial();
	glBindTexture(GL_TEXTURE_2D, armorPlateTextures);
	glBegin(GL_QUADS);
	//front
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, 0.2f, 0.0f);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.2f, 0.0f);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.2f, 0.0f);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, 0.0f);

	//back
	glTexCoord2f(0.3f, 0.3f);	glVertex3f(0.1f, 0.2f, 0.03f);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.2f, 0.03f);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.2f, 0.03f);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, 0.03f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, armorPlateSideTextures);
	glBegin(GL_QUADS);
	//left
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, 0.0f);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, -0.2f, 0.0f);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.2f, 0.03f);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, 0.03f);

	//right
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, 0.2f, 0.0f);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.2f, 0.0f);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.2f, 0.03f);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, 0.2f, 0.03f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, armorPlateSideTextures);
	glBegin(GL_QUADS);
	//up
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, 0.0f);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, 0.2f, 0.0f);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.2f, 0.03f);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, 0.03f);

	//down
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, -0.2f, 0.0f);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.2f, 0.0f);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.2f, 0.03f);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, -0.2f, 0.03f);
	glEnd();
}
void drawHat(GLUquadricObj* object) {
	//hat
	glPushMatrix(); {
		glTranslatef(0, -0.1f, 0.3f);
		glRotatef(90, 1, 0, 0);
		glPushMatrix(); {

			redMaterial();
			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glPushAttrib(1);
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			gluCylinder(object, 1.2, 0.01, 0.2, 100, 100);
			glPopAttrib();
			grayMaterial();
			glPushAttrib(1);
			glColor3f(0, 0, 0);
			glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
			gluDisk(object, 0.56, 0.6, 100, 100);
			gluDisk(object, 1.16, 1.2, 100, 100);
			gluQuadricDrawStyle(object, GLU_LINE);
			gluCylinder(object, 1.2, 0.01, 0.2, 40, 40);
			glPopAttrib();

		}glPopMatrix();
	}glPopMatrix();
	//horn 212, 175, 55
	glPushMatrix(); {
		glTranslatef(0, -0.3f, 0.3f);
		glRotatef(180, 0, 0, 1);
		glPushMatrix(); {
			glPushAttrib(1);
			glColor3f(212 / 255.0f, 175 / 255.0f, 55 / 255.0f);

			goldMaterial();
			glBindTexture(GL_TEXTURE_2D, goldMetalTextures);

			glBegin(GL_QUADS);
			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.05f, 0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.05f, 0.1f, -0.05f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.5f, 0.2f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.5f, 0.4f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.5f, 0.4f, -0.05f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.5f, 0.2f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.05f, 0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.5f, 0.4f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.5f, 0.2f, 0.0f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.05f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.05f, 0.1f, -0.05f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.5f, 0.4f, -0.05f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.5f, 0.2f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.05f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.5f, 0.2f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.5f, 0.2f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.05f, 0.1f, -0.05f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.05f, 0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.5f, 0.4f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.5f, 0.4f, -0.05f);

			//right
			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.05f, 0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.05f, 0.1f, -0.05f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(-0.5f, 0.2f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.5f, 0.4f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.5f, 0.4f, -0.05f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.5f, 0.2f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.05f, 0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.5f, 0.4f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.5f, 0.2f, 0.0f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.05f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.05f, 0.1f, -0.05f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.5f, 0.4f, -0.05f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.5f, 0.2f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(-0.0f, 0.0f, -0.05f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.0f, 0.0f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.5f, 0.2f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.5f, 0.2f, -0.05f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(-0.05f, 0.1f, -0.05f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.05f, 0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.5f, 0.4f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.5f, 0.4f, -0.05f);
			glEnd();

			glPopAttrib();
		}glPopMatrix();

	}glPopMatrix();
	//disk
	glPushMatrix(); {
		glRotatef(180, 0, 0, 1);
		glRotatef(25, 1, 0, 0);
		glTranslatef(0, 0.5f, 0);

		whiteMaterial();
		glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
		gluQuadricDrawStyle(object, GLU_FILL);
		gluPartialDisk(object, 0.15, 0.2, 50, 50, 5, 355);

	}glPopMatrix();
}
void drawHead(GLUquadricObj* object) {
	glPushMatrix(); {
		redMaterial();
		glPushAttrib(1);
		glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
		glScalef(2.0f, 2.0f, 1.5);
		glTranslatef(0.0f, 0.1f, 0.08f);
		glRotatef(180, 1, 0, 0);
		glRotatef(180, 0, 1, 0);

		//chin
		glPushMatrix(); {

			//right
			glPushMatrix(); {



				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				//right
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.25f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.05f, -0.25f, -0.05f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.15f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.1f, 0.0f);

				//left
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.25f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.05f, -0.25f, -0.05f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.15f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.1f, 0.0f);

				//behind
				//right
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.05f, -0.25f, 0.15f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, -0.1f, 0.25f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.15f, -0.1f, 0.25f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.05f, -0.25f, 0.15f);

				//left
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.25f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.05f, -0.25f, -0.05f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.15f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.1f, 0.0f);

				//under
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.05f, -0.25f, -0.05f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.05f, -0.25f, -0.05f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.05f, -0.25f, 0.15f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.05f, -0.25f, 0.15f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.05f, -0.25f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.15f, 0.1f, 0.25f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.05f, -0.25f, 0.15f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.05f, -0.25f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.15f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.15f, 0.1f, 0.25f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.05f, -0.25f, 0.15f);
				glEnd();


			}
			glPopMatrix();

			//side right
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.05f, -0.25f, -0.05f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.05f, -0.25f, 0.05f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.05f, -0.25f, 0.15f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, -0.1f, 0.25f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.15f, -0.1f, 0.15f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.05f, -0.25f, -0.05f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.15f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.05f, -0.25f, 0.05f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.05f, -0.25f, 0.15f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.15f, -0.1f, 0.25f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.15f, -0.1f, 0.15f);
				glEnd();

			}glPopMatrix();

		}glPopMatrix();

		//face
		glPushMatrix(); {

			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glBegin(GL_QUADS);

			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.15f, -0.1f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, 0.15f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.15f, 0.15f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.15f, -0.1f, 0.0f);

			//behind
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.15f, -0.1f, 0.25f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, 0.15f, 0.25f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.15f, 0.15f, 0.25f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.15f, -0.1f, 0.25f);

			//side left
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.15f, -0.1f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.15f, 0.15f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.15f, 0.15f, 0.25f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.15f, -0.1f, 0.25f);

			//side right
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.15f, -0.1f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.15f, 0.15f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.15f, 0.15f, 0.25f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.15f, -0.1f, 0.25f);
			glEnd();

		}glPopMatrix();

		//fore head
		glPushMatrix(); {
			//right

			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.15f, 0.15f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.2f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, 0.2f, 0.0f);

			//left
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.15f, 0.15f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.2f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, 0.2f, 0.0f);

			//side right
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.15f, 0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, 0.2f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.2f, 0.2f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.15f, 0.15f, 0.25f);

			//side left
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.15f, 0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, 0.2f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.2f, 0.2f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.15f, 0.15f, 0.25f);
			glEnd();


		}glPopMatrix();

		glPopAttrib();
	}glPopMatrix();
}
void drawFace(GLUquadricObj* object) {

	glPushMatrix(); {
		//eye
		glPushMatrix(); {
			whiteMaterial();
			glPushMatrix(); {
				glTranslatef(0, 0, 0.2);
				//glTranslatef(0.14, 0, 0.05);
				//glColor3f(82/ 255.0f, 125/ 255.0f, 243/ 255.0f);
				glColor3f(1, 1, 1);
				glPushMatrix(); {
					glRotatef(90 + 30, 1, 1, 1);
					glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
					gluQuadricDrawStyle(object, GLU_FILL);
					gluSphere(object, 0.17, 100, 100);

				}glPopMatrix();

				glPushAttrib(1);
				glTranslatef(0, 0, -0.0999);
				glColor3f(26 / 255.0f, 163 / 255.0f, 109 / 255.0f);

				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				gluQuadricDrawStyle(object, GLU_FILL);
				gluDisk(object, 0.17, 0.2, 100, 100);
				gluCylinder(object, 0.17, 0.17, 0.2, 100, 100);
				gluCylinder(object, 0.2, 0.2, 0.2, 100, 100);

				glPopAttrib();
				glPushMatrix(); {

				}glPopMatrix();
			}glPopMatrix();
		}glPopMatrix();
		//spin 
		glPushMatrix(); {
			glTranslatef(0.33f, 0, 0.25f);
			glRotatef(-90, 0, 1, 0);
			glPushMatrix(); {
				glScalef(0.4, 0.4, 0);
				glPushMatrix(); {
					if (isActive)
					{
						rotateReactor += ZWspeed;
					}
					else
					{
						rotateReactor = 0;
					}
					glRotatef(rotateReactor, 0, 0, 1);
					glPushAttrib(1);
					glColor3f(0, 0, 0);
					glBegin(GL_TRIANGLES);
					glVertex2f(0.0f, 0.0f);
					glVertex2f(0.1f, 0.2f);
					glVertex2f(0.2f, 0.1f);
					glEnd();
					glPopAttrib();
				}glPopMatrix();
			}glPopMatrix();
		}glPopMatrix();

		//ear
		glPushMatrix(); {
			whiteMaterial();
			glTranslatef(0.3f, 0, 0.25f);
			glRotatef(90, 0, 1, 0);
			glPushMatrix(); {
				glTranslatef(0, 0, 0.01f);

				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				gluQuadricDrawStyle(object, GLU_FILL);

				gluDisk(object, 00, 0.1, 100, 100);

			}glPopMatrix();
			gluCylinder(object, 0.1, 0.1, 0.05, 100, 100);

		}glPopMatrix();


		//beard #1
		glPushMatrix(); {
			glPushAttrib(1);
			whiteMaterial();
			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			//green
			glColor3f(26 / 255.0f, 163 / 255.0f, 109 / 255.0f);
			glPushMatrix(); {
				glRotatef(-25, 0, 1, 0);
				glTranslatef(0, 0.7f, -0.03f);
				glBegin(GL_QUADS);
				glVertex2f(0.0f, -0.05f);
				glVertex2f(0.1f, -0.15f);
				glVertex2f(0.1f, -0.2f);
				glVertex2f(0.0f, -0.2f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glVertex2f(0.0f, -0.2f);
				glVertex2f(0.1f, -0.2f);
				glVertex2f(0.0f, -0.3f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glVertex2f(0.1f, -0.2f);
				glVertex2f(0.6f, -0.6f);
				glVertex2f(0.0f, -0.3f);
				glEnd();
			}glPopMatrix();

			//left
			glPushMatrix(); {
				glRotatef(25, 0, 1, 0);
				glTranslatef(0, 0.7f, -0.03f);
				glBegin(GL_QUADS);
				glVertex2f(0.0f, -0.05f);
				glVertex2f(-0.1f, -0.15f);
				glVertex2f(-0.1f, -0.2f);
				glVertex2f(0.0f, -0.2f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glVertex2f(0.0f, -0.2f);
				glVertex2f(-0.1f, -0.2f);
				glVertex2f(0.0f, -0.3f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glVertex2f(-0.1f, -0.2f);
				glVertex2f(-0.6f, -0.6f);
				glVertex2f(0.0f, -0.3f);
				glEnd();
			}glPopMatrix();
			glPopAttrib();


		}glPopMatrix();

		//beard #2
		glPushMatrix(); {
			goldMaterial();
			//glColor3f(0, 1, 0);
			glTranslatef(0, 0.8f, -0.04f);
			glRotatef(270, 1, 0, 0);


			glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
			glBegin(GL_TRIANGLES);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(-0.1f, -0.1f, 0.0f);
			glVertex3f(0.1f, -0.1f, 0.0f);

			glVertex3f(0.0f, 0.0f, -0.4f);
			glVertex3f(-0.1f, -0.1f, -0.4f);
			glVertex3f(0.1f, -0.1f, -0.4f);
			glEnd();



			glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.1f, -0.1f, -0.4f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.4f);

			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, -0.1f, 0.0f);
			glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.1f, -0.1f, -0.4f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.0f, 0.0f, -0.4f);
			glEnd();


		}glPopMatrix();

	}glPopMatrix();
}
void drawNeck(GLUquadricObj* object) {
	//top
	glPushMatrix(); {
		whiteMaterial();
		glPushMatrix(); {
			glScalef(1.5, 1.8, 1.5);
			glTranslatef(0, 0.08f, 0.335f);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			glBegin(GL_QUADS);
			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, 0.15f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.15f, 0.0f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, -0.15f, 0.0f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.1f, -0.15f, 0.1f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, -0.15f, 0.1f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, -0.15f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, -0.15f, 0.1f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.15f, 0.1f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, 0.15f, 0.0f);

			glTexCoord2f(0.5f, 0.5f);glVertex3f(-0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, -0.15f, 0.1f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.15f, 0.0f);
			glEnd();

		}glPopMatrix();

		glPushMatrix(); {
			glScalef(1.0, 1.3, 1.0);
			glTranslatef(0, 0.08f, 0.65f);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, 0.15f, 0.0f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.15f, 0.0f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.1f, -0.15f, 0.0f);

			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, -0.15f, 0.1f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.1f, -0.15f, 0.1f);

			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, -0.15f, 0.0f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, -0.15f, 0.1f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.1f, -0.15f, 0.1f);

			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(0.1f, -0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.1f, 0.15f, 0.0f);

			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, -0.15f, 0.0f);
			glTexCoord2f(0.5f, -0.5f);glVertex3f(-0.1f, -0.15f, 0.1f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.15f, 0.1f);
			glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.1f, 0.15f, 0.0f);
			glEnd();

		}glPopMatrix();

	}glPopMatrix();

	//mid
	glPushAttrib(1);
	glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
	glPushMatrix(); {
		//mid
		glPushMatrix(); {
			glTranslatef(0.0f, 1.3f, 0.3f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.06, 0.06, 0.7f, 40, 40);


			gluDisk(object, 0, 0.06, 50, 1);
		}glPopMatrix();

		//right
		glPushMatrix(); {

			glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
			glTranslatef(0.2f, 0.4f, 0.43f);
			glRotatef(90, 0, 1, 0);
			glRotatef(-40, 1, 0, 0);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.06, 0.06, 0.8, 40, 40);
			gluDisk(object, 0, 0.06, 50, 1);

		}glPopMatrix();

		glPushMatrix(); {

			glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
			glTranslatef(0.2f, 0.4f, 0.3f);
			glRotatef(90, 0, 1, 0);
			glRotatef(-60, 1, 0, 0);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.06, 0.06, 0.6, 40, 40);
			gluDisk(object, 0, 0.06, 50, 1);

		}glPopMatrix();

		//left
		glPushMatrix(); {

			glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
			glTranslatef(-0.2f, 0.4f, 0.43f);
			glRotatef(-90, 0, 1, 0);
			glRotatef(-40, 1, 0, 0);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.06, 0.06, 0.8, 40, 40);
			gluDisk(object, 0, 0.06, 50, 1);

		}glPopMatrix();

		glPushMatrix(); {

			glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
			glTranslatef(-0.2f, 0.4f, 0.3f);
			glRotatef(-90, 0, 1, 0);
			glRotatef(-60, 1, 0, 0);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.06, 0.06, 0.6, 40, 40);
			gluDisk(object, 0, 0.06, 50, 1);

		}glPopMatrix();

	}glPopMatrix();
	glPopAttrib();

	grayMaterial();
	//btm
	glPushMatrix(); {
		glRotatef(85, 1, 0, 0);
		glTranslatef(0, 0.5f, -0.8f);

		glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
		gluQuadricDrawStyle(object, GLU_FILL);
		gluCylinder(object, 0.35, 0.02, 0.67, 40, 40);

	}glPopMatrix();

}
void drawBody(GLUquadricObj* object) {

	glPushMatrix(); {
		goldMaterial();
		glScalef(3, 2, 3);
		glTranslatef(0, 0, -0.15f);
		glRotatef(90, 1, 0, 0);
		//chest
		glPushMatrix(); {

			//front
			glPushMatrix(); {
				glPushAttrib(1);
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);

				//  
				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.0f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.0f, -0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, -0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.05f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.4f, 0.0f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.0f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.05f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.4f, 0.0f, 0.0f);
				glEnd();

				//   


				glBindTexture(GL_TEXTURE_2D, BodyTextures);

				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.05f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.05f, 0.0f);
				glEnd();


				glPopAttrib();

			}glPopMatrix();

			//back
			glPushMatrix(); {
				glPushAttrib(1);
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);

				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.0f, 0.4f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.0f, 0.4f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.4f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, 0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.0f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, 0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, 0.4f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.5f, -0.3f);glVertex3f(0.2f, 0.2f, 0.4f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.5f, 0.5f);glVertex3f(0.4f, 0.05f, 0.2f);

				glTexCoord2f(0.5f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.4f);
				glTexCoord2f(-0.5f, -0.5f);glVertex3f(-0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.5f, 0.5f);glVertex3f(-0.4f, 0.05f, 0.2f);
				glEnd();


				glPopAttrib();


			}glPopMatrix();

			//right
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				glPushAttrib(1);
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, 0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.0f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, 0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.0f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.4f, 0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.4f, 0.05f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.4f, 0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.4f, 0.05f, 0.2f);
				glEnd();
				glPopAttrib();

			}glPopMatrix();

			//left
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				glPushAttrib(1);
				//crimson red
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				glBegin(GL_QUADS);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, 0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, 0.0f);


				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, 0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, 0.2f);


				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.4f, 0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.4f, 0.05f, 0.2f);


				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.4f, 0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.4f, 0.05f, 0.2f);
				glEnd();
				glPopAttrib();

			}glPopMatrix();

			//head plug in
			glPushMatrix(); {

				glPushAttrib(1);
				glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);

				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.1f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, 0.1f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, 0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.1f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.1f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, 0.1f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, 0.1f, 0.2f);

				glEnd();

				glPopAttrib();

			}glPopMatrix();
		}glPopMatrix();

		//lower chest
		glPushMatrix(); {
			glPushAttrib(1);
			//crimson red
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);

			//front
			glPushMatrix(); {


				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.0f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.0f, -0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, -0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.4f, 0.0f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, 0.0f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.4f, 0.0f, 0.0f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.3f, 0.3f);
				glVertex3f(-0.2f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.05f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, -0.05f, 0.0f);
				glEnd();


			}glPopMatrix();

			//back
			glPushMatrix(); {


				glBindTexture(GL_TEXTURE_2D, BodyTextures);

				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, 0.0f, 0.4f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, 0.0f, 0.4f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.4f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, -0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.0f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, -0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, 0.4f);
				glEnd();

				glBegin(GL_TRIANGLES);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, -0.05f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, -0.05f, 0.2f);
				glEnd();


			}glPopMatrix();

			//right
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.0f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, -0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, 0.0f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.4f, -0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.4f, -0.05f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.4f, -0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.4f, -0.05f, 0.2f);
				glEnd();


			}glPopMatrix();

			//left
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, BodyTextures);

				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, -0.05f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, -0.05f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, 0.0f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.4f, -0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.4f, 0.0f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.4f, -0.05f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.4f, -0.05f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.4f, -0.05f, 0.2f);
				glEnd();


			}glPopMatrix();

			// plug in
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.1f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, -0.1f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.0f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.1f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, -0.1f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, -0.1f, 0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.1f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, -0.1f, 0.2f);
				glEnd();

			}glPopMatrix();
			glPopAttrib();



		}glPopMatrix();

		//chest pack
		glPushMatrix(); {
			glPushAttrib(1);
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			//front
			glPushMatrix(); {
				//right

				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.4f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.35f, 0.0f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, -0.2f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.4f, 0.0f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.35f, 0.0f);
				glEnd();


			}glPopMatrix();

			//back
			glPushMatrix(); {
				//right


				glBindTexture(GL_TEXTURE_2D, BodyTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.2f, -0.2f, 0.4f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.4f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.35f, 0.2f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.0f, -0.2f, 0.4f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.2f, -0.2f, 0.4f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.4f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.35f, 0.2f);
				glEnd();


			}glPopMatrix();
			glPopAttrib();

			glPushAttrib(1);
			glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
			//connect
			glPushMatrix(); {


				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				glBegin(GL_QUADS);
				glTexCoord2f(0.3f, 0.3f);glVertex3f(0.2f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, -0.4f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, -0.4f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.2f, -0.2f, 0.4f);

				glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, -0.2f);
				glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, -0.4f, 0.0f);
				glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, -0.4f, 0.2f);
				glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.2f, -0.2f, 0.4f);
				glEnd();


			}glPopMatrix();
			glPopAttrib();

		}glPopMatrix();

		//chest pact lower 
		glPushMatrix(); {
			glPushAttrib(1);
			glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
			glTranslatef(0, 0, 0.1f);
			glRotatef(90, 1, 0, 0);

			gluQuadricDrawStyle(object, GLU_FILL);
			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluCylinder(object, 0.15, 0.15, 0.5, 40, 40);
			glPushMatrix(); {
				glTranslatef(0, 0.f, 0.02f);
				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				gluCylinder(object, 0.14, 0.13, 0.5, 40, 40);
			}glPopMatrix();

			glPushMatrix(); {
				glTranslatef(0, 0.f, 0.04f);
				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				gluCylinder(object, 0.12, 0.11, 0.5, 40, 40);
			}glPopMatrix();

			glPushMatrix(); {
				glTranslatef(0, 0.f, 0.06f);
				glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
				gluCylinder(object, 0.11, 0.10, 0.5, 40, 40);
			}glPopMatrix();

			glPushMatrix(); {
				glTranslatef(0, 0.f, 0.08f);
				glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
				gluCylinder(object, 0.09, 0.08, 0.7, 40, 40);
			}glPopMatrix();


			glPopAttrib();
		}glPopMatrix();
	}glPopMatrix();
}
void drawArmor(GLUquadricObj* object) {
	//shoulder plate
	glPushMatrix(); {
		redMaterial();
		glPushAttrib(1);
		//crimson red
		glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
		//right shoulder
		glPushMatrix(); {
			glScalef(2.0f, 3.0f, 2.0f);
			glTranslatef(0.4f, -0.067f, 0);
			glRotatef(40, 0, 1, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(2.0f, 3.0f, 2.0f);
			glTranslatef(0.48f, -0.067f, -0.04f);
			glRotatef(48, 0, 1, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(2.0f, 3.0f, 2.0f);
			glTranslatef(0.56f, -0.067f, -0.08f);
			glRotatef(56, 0, 1, 0);
			drawArmorPlate();
		}glPopMatrix();

		//left shoulder
		glPushMatrix(); {
			glScalef(2.0f, 3.0f, 2.0f);
			glTranslatef(-0.4f, -0.067f, 0);
			glRotatef(-40, 0, 1, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(2.0f, 3.0f, 2.0f);
			glTranslatef(-0.48f, -0.067f, -0.04f);
			glRotatef(-48, 0, 1, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(2.0f, 3.0f, 2.0f);
			glTranslatef(-0.56f, -0.067f, -0.08f);
			glRotatef(-56, 0, 1, 0);
			drawArmorPlate();
		}glPopMatrix();
		glPopAttrib();
	}glPopMatrix();

	//body stand
	//right
	whiteMaterial();
	glPushMatrix(); {
		glPushMatrix(); {
			glTranslatef(0.5f, -0.1f, 0);
			glRotatef(45, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);

		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(0.5f, -0.3f, 0.2f);
			glRotatef(90, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.5, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(0.5f, -0.9f, 0.025f);
			glRotatef(-45, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(0.5f, -0.9f, -1.0f);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 1.1, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(0.5f, -0.95f, -0.9f);
			glRotatef(225, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.34, 100, 100);


		}glPopMatrix();


	}glPopMatrix();
	//left
	glPushMatrix(); {
		glPushMatrix(); {
			glTranslatef(-0.5f, -0.1f, 0);
			glRotatef(45, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.5f, -0.3f, 0.2f);
			glRotatef(90, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.5, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.5f, -0.9f, 0.025f);
			glRotatef(-45, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.5f, -0.9f, -1.0f);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 1.1, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.5f, -0.95f, -0.9f);
			glRotatef(225, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.34, 100, 100);


		}glPopMatrix();


	}glPopMatrix();

	//back
	//left
	glPushMatrix(); {
		glPushMatrix(); {
			glTranslatef(0.5f, 0.1f, 0);
			glRotatef(-45, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(0.5f, 0.25f, 0.2f);
			glRotatef(-90, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(0.5f, 0.55f, -0.01f);
			glRotatef(25, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.01f, 0.55f, -0.9f);
			glRotatef(30, 0, 1, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 1.1, 100, 100);


		}glPopMatrix();
	}glPopMatrix();

	//right
	glPushMatrix(); {
		glPushMatrix(); {
			glTranslatef(-0.5f, 0.1f, 0);
			glRotatef(-45, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.5f, 0.25f, 0.2f);
			glRotatef(-90, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.5f, 0.55f, -0.01f);
			glRotatef(25, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.3, 100, 100);


		}glPopMatrix();

		glPushMatrix(); {
			glTranslatef(-0.01f, 0.55f, -0.9f);
			glRotatef(-30, 0, 1, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 1.1, 100, 100);


		}glPopMatrix();
	}glPopMatrix();

	//back pin
	glPushMatrix(); {
		glTranslatef(0, 0.45f, -1.0f);
		glPushAttrib(1);
		glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);

		glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
		gluQuadricDrawStyle(object, GLU_FILL);
		gluSphere(object, 0.17, 100, 100);


		glPopAttrib();

	}glPopMatrix();
}
void drawReactor(GLUquadricObj* object) {
	glPushMatrix(); {
		goldMaterial();
		glTranslatef(0, -0.7f, -0.4f);
		//ring outer
		glPushMatrix(); {
			glRotatef(-270, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
			gluCylinder(object, 0.3, 0.35, 0.25, 100, 100);
			gluCylinder(object, 0.3, 0.3, 0.25, 100, 100);
			glPushMatrix(); {
				glTranslatef(0, 0.0f, 0.2f);
				gluDisk(object, 0.3, 0.35, 100, 100);
			}glPopMatrix();



		}glPopMatrix();

		//spinign 
		glPushMatrix(); {
			if (isActive)
			{
				rotateReactor += ZWspeed;
			}
			else
			{
				rotateReactor = 0;
			}
			glTranslatef(0, -0.2f, 0);
			glRotatef(90, 1, 0, 0);
			glPushMatrix(); {
				glRotatef(rotateReactor, 0, 0, 1);
				glPushAttrib(1);
				glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);

				glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 0, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 24, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 48, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 72, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 96, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 120, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 144, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 168, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 192, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 216, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 240, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 264, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 288, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 312, 12);
				gluPartialDisk(object, 0.1, 0.3, 100, 100, 336, 12);


				glPopAttrib();
			}glPopMatrix();

		}glPopMatrix();

		//orb
		glPushMatrix(); {
			if (isActive)
			{
				rotateReactor += ZWspeed;
			}
			else
			{
				rotateReactor = 0;
			}
			glRotatef(rotateReactor, 0, 1, 0);

			glBindTexture(GL_TEXTURE_2D, umbrellaTextures);
			glPushAttrib(1);
			//green
			glColor3f(26 / 255.0f, 163 / 255.0f, 109 / 255.0f);
			gluSphere(object, 0.3, 100, 100);
			glPopAttrib();

		}glPopMatrix();

	}glPopMatrix();
}
void drawKatana(GLUquadricObj* object) {
	float theta;
	//katanaHandlerTextures
	//grip
	glPushMatrix(); {
		glTranslatef(0, 0.2f, 7.0f);
		glRotatef(90, 0, 0, 1);
		//grip
		glPushMatrix(); {
			glScalef(2.5, 1, 5);
			glPushAttrib(1);
			//crimson red
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);

			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			gluQuadricDrawStyle(object, GLU_FILL);
			gluCylinder(object, 0.1, 0.1, 0.5, 100, 100);


			glPopAttrib();
			glPushAttrib(1);
			glColor3f(0, 0, 0);

			glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
			gluQuadricDrawStyle(object, GLU_LINE);
			gluCylinder(object, 0.11, 0.11, 0.5, 30, 30);

			glPopAttrib();
			gluDisk(object, 00, 0.1, 100, 100);
		}glPopMatrix();

		//kata plate
		glPushMatrix(); {
			glPushAttrib(1);
			glScalef(2.5, 1, 1);
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);

			glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
			gluCylinder(object, 0.105, 0.105, 0.2, 100, 100);

			//gluDisk(object, 00, 0.4, 100, 100);
			glPopAttrib();
		}glPopMatrix();
	}glPopMatrix();

	//blade
	glPushMatrix(); {
		glScalef(4, 4, 4);
		glRotatef(90, 1, 0, 0);
		glRotatef(90, 0, 1, 0);
		glPushMatrix(); {
			glPushAttrib(1);
			glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);

			glBindTexture(GL_TEXTURE_2D, katanaBladeTextures);
			glBegin(GL_TRIANGLES);
			glTexCoord2f(218 / 600.0f, 288 / 600.0f);glVertex3f(0.0f, 0.0f, 0.01f);
			glTexCoord2f(385 / 600.0f, 288 / 600.0f);glVertex3f(0.1f, 0.0f, 0.0f);
			glTexCoord2f(271 / 600.0f, 354 / 600.0f);glVertex3f(0.0f, -0.2f, 0.0f);
			glTexCoord2f(218 / 600.0f, 288 / 600.0f);glVertex3f(0.0f, 0.0f, -0.01f);
			glTexCoord2f(385 / 600.0f, 288 / 600.0f);glVertex3f(0.1f, 0.0f, 0.0f);
			glTexCoord2f(271 / 600.0f, 354 / 600.0f);glVertex3f(0.0f, -0.2f, 0.0f);
			glVertex3f(0.0f, 0.0f, -0.01f);
			glVertex3f(0.0f, -0.2f, 0.0f);
			glVertex3f(0.0f, 0.0f, 0.01f);
			glEnd();


			glBindTexture(GL_TEXTURE_2D, katanaBladeTextures);
			glBegin(GL_QUADS);
			glTexCoord2f(162 / 600.0f, 338 / 600.0f);glVertex3f(0.0f, 0.0f, 0.01f);
			glTexCoord2f(162 / 600.0f, 144 / 600.0f);glVertex3f(0.0f, 1.8f, 0.01f);
			glTexCoord2f(413 / 600.0f, 144 / 600.0f);glVertex3f(0.1f, 1.8f, 0.0f);
			glTexCoord2f(413 / 600.0f, 338 / 600.0f);glVertex3f(0.1f, 0.0f, 0.0f);
			glTexCoord2f(162 / 600.0f, 338 / 600.0f);glVertex3f(0.0f, 0.0f, -0.01f);
			glTexCoord2f(162 / 600.0f, 144 / 600.0f);glVertex3f(0.0f, 1.8f, -0.01f);
			glTexCoord2f(413 / 600.0f, 144 / 600.0f);glVertex3f(0.1f, 1.8f, 0.0f);
			glTexCoord2f(413 / 600.0f, 338 / 600.0f);glVertex3f(0.1f, 0.0f, 0.0f);
			glTexCoord2f(162 / 600.0f, 338 / 600.0f);glVertex3f(0.0f, 0.0f, -0.01f);
			glTexCoord2f(162 / 600.0f, 144 / 600.0f);glVertex3f(0.0f, 0.0f, 0.01f);
			glTexCoord2f(413 / 600.0f, 144 / 600.0f);glVertex3f(0.0f, 1.8f, 0.01f);
			glTexCoord2f(413 / 600.0f, 338 / 600.0f);glVertex3f(0.0f, 1.8f, -0.01f);
			glEnd();

			glPopAttrib();
		}glPopMatrix();

	}glPopMatrix();

}
void drawKatanaCover(GLUquadricObj* object) {
	//kata cover
	glPushMatrix(); {

		//open cover
		//glTranslatef(0.6f, 0.0f, -2.0f);

		//close
		glTranslatef(0, 0.0f, 1.0f);
		glPushMatrix(); {
			glTranslatef(0, 0.2f, 6.0f);
			glRotatef(90, 0, 0, 1);
			glRotatef(180, 1, 0, 0);
			//grip
			glPushMatrix(); {
				glScalef(2.5, 1, 5);


				glBindTexture(GL_TEXTURE_2D, whiteTextures);
				gluQuadricDrawStyle(object, GLU_FILL);
				gluCylinder(object, 0.1, 0.1, 1.6, 100, 100);



				gluDisk(object, 00, 0.1, 100, 100);
			}glPopMatrix();

			//kata plate
			glPushMatrix(); {

				glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
				glPushAttrib(1);
				glScalef(2.5, 1, 1);
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				gluCylinder(object, 0.105, 0.105, 0.2, 100, 100);
				//gluDisk(object, 00, 0.4, 100, 100);
				glPopAttrib();


			}glPopMatrix();
		}glPopMatrix();
	}glPopMatrix();
}
//--------------------HAND-------------------------------------
void drawSphere(double r, GLenum type) {
	grayMaterial();
	GLUquadricObj* sphere = NULL;
	sphere = gluNewQuadric();
	gluQuadricDrawStyle(sphere, type);
	glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
	gluQuadricTexture(sphere, GL_TRUE);
	gluSphere(sphere, r, 30, 30);
	gluDeleteQuadric(sphere);
}
void drawCylinder(float tr, float br, float h, GLenum type) {
	grayMaterial();
	GLUquadricObj* cylinder = NULL;
	cylinder = gluNewQuadric();
	gluQuadricDrawStyle(cylinder, type);
	glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
	gluQuadricTexture(cylinder, GL_TRUE);
	gluCylinder(cylinder, tr, br, h, 30, 30);
	gluDeleteQuadric(cylinder);
}
void drawPyramid(float minX, float maxX, float minY, float maxY, float minZ, float maxZ, float divX, float divZ, GLenum type, GLenum base) {
	whiteMaterial();
	glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
	//face - back
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, minY, minZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(maxX, minY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX / divX, maxY, maxZ / divZ);
	glEnd();

	//face - top
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, minY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, minY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX / divX, maxY, maxZ / divZ);
	glEnd();

	//face - bottom
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(maxX, minY, minZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(maxX, minY, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX / divX, maxY, maxZ / divZ);
	glEnd();

	//face - front
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, minY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(maxX, minY, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX / divX, maxY, maxZ / divZ);
	glEnd();

	//face - base
	glBegin(base);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, minY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(maxX, minY, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, minY, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(minX, minY, minZ);
	glEnd();

}
void drawRec(float minX, float maxX, float minY, float maxY, float minZ, float maxZ, GLenum type) {

	//Back
	glBegin(type);
	//glTexCoord2f(0.0, 0.0);

	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, maxY, minZ);
	//glTexCoord2f(0.0, 1.0);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, minY, minZ);
	//glTexCoord2f(1.0, 1.0);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, minY, minZ);
	//glTexCoord2f(1.0, 0.0);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(maxX, maxY, minZ);
	glEnd();

	//Bottom
	glBegin(type);
	//glTexCoord2f(0.0, 0.0);
	glVertex3f(minX, minY, maxZ);
	//glTexCoord2f(0.0, 1.0);
	glVertex3f(minX, minY, minZ);
	//glTexCoord2f(1.0, 1.0);
	glVertex3f(maxX, minY, minZ);
	//glTexCoord2f(1.0, 0.0);
	glVertex3f(maxX, minY, maxZ);
	glEnd();

	//Left
	glBegin(type);
	//glTexCoord2f(0.0, 0.0);
	glVertex3f(minX, maxY, maxZ);
	//glTexCoord2f(0.0, 1.0);
	glVertex3f(minX, maxY, minZ);
	//glTexCoord2f(1.0, 1.0);
	glVertex3f(minX, minY, minZ);
	//glTexCoord2f(1.0, 0.0);
	glVertex3f(minX, minY, maxZ);
	glEnd();

	//Top
	glBegin(type);
	//glTexCoord2f(0.0, 0.0);
	glVertex3f(minX, maxY, maxZ);
	//glTexCoord2f(0.0, 1.0);
	glVertex3f(minX, maxY, minZ);
	//glTexCoord2f(1.0, 1.0);
	glVertex3f(maxX, maxY, minZ);
	//glTexCoord2f(1.0, 0.0);
	glVertex3f(maxX, maxY, maxZ);
	glEnd();

	//Right
	glBegin(type);
	//glTexCoord2f(0.0, 0.0);
	glVertex3f(maxX, maxY, maxZ);
	//glTexCoord2f(0.0, 1.0);
	glVertex3f(maxX, maxY, minZ);
	//glTexCoord2f(1.0, 1.0);
	glVertex3f(maxX, minY, minZ);
	//glTexCoord2f(1.0, 0.0);
	glVertex3f(maxX, minY, maxZ);
	glEnd();

	//Front
	glBegin(type);
	//glTexCoord2f(0.0, 0.0);
	glVertex3f(minX, maxY, maxZ);
	//glTexCoord2f(0.0, 1.0);
	glVertex3f(minX, minY, maxZ);
	//glTexCoord2f(1.0, 1.0);
	glVertex3f(maxX, minY, maxZ);
	//glTexCoord2f(1.0, 0.0);
	glVertex3f(maxX, maxY, maxZ);
	glEnd();

}
void drawRecT(float minX, float maxX, float minY, float maxY, float minZ, float maxZ, GLenum type, int textureType) {
	if (textureType == 1) {
		glBindTexture(GL_TEXTURE_2D, BodyTextures);
	}
	else if (textureType == 2) {
		glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
	}
	else if (textureType == 3) {
		glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
	}
	else if (textureType == 4) {
		glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
	}

	//Back
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, maxY, minZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, minY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, minY, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(maxX, maxY, minZ);
	glEnd();

	//Bottom
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, minY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, minY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, minY, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(maxX, minY, maxZ);
	glEnd();

	//Left
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, maxY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, maxY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(minX, minY, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(minX, minY, maxZ);
	glEnd();

	//Top
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, maxY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, maxY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, maxY, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(maxX, maxY, maxZ);
	glEnd();

	//Right
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(maxX, maxY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(maxX, maxY, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, minY, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(maxX, minY, maxZ);
	glEnd();

	//Front
	glBegin(type);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(minX, maxY, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(minX, minY, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(maxX, minY, maxZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(maxX, maxY, maxZ);
	glEnd();

}
void leftHand() {
	whiteMaterial();
	glPushAttrib(1);
	//grey bar
	//glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
	//white
	glColor3f(1, 1, 1);

	//Palm
	drawRecT(1.5f, 2.1f, -0.05f, 0.55f, 0.15f, 0.3f, GL_QUADS, 2);
	drawRecT(1.5f, 2.1f, -0.00f, 0.55f, 0.15f, 0.3f, GL_QUADS, 2);
	drawRecT(1.5f, 2.1f, -0.05f, 0.00f, 0.15f, 0.3f, GL_QUADS, 2);
	glPushMatrix();


	//Thumb
	drawPyramid(1.5, 1.7f, 0.55f, 0.65f, 0.2f, 0.3f, 1.08f, 2.0f, GL_TRIANGLES, GL_QUADS);
	drawPyramid(1.5, 1.7f, 0.00f, 0.65f, 0.2f, 0.3f, 1.08f, 2.0f, GL_TRIANGLES, GL_QUADS);
	drawPyramid(1.5, 1.7f, 0.55f, 0.00f, 0.2f, 0.3f, 1.08f, 2.0f, GL_TRIANGLES, GL_QUADS);
	glPushMatrix();
	//initial position of the thumb finger(inner, outer) - no animation
	glTranslatef(1.56f, 0.70f, 0.3f);
	glRotatef(42.0f, 0.0f, 0.0f, 0.5f);
	glTranslatef(-1.56f, -0.70f, -0.3f);
	//inner
	glTranslatef(1.56f, 0.65f, 0.3f);
	glRotatef(initialThumbMove, 0.0f, -0.5f, 0.0f);
	initialThumbMove += thumbMove;
	glTranslatef(-1.56f, -0.65f, -0.3f);
	if (initialThumbMove >= 45.0f) {

		initialThumbMove = 45.0f;
		thumbMove = 0.0f;

	}
	else if (initialThumbMove <= 0.0f) {

		initialThumbMove = 0.0f;
		thumbMove = 0.0f;

	}
	drawRecT(1.56f, 1.76f, 0.50f, 0.65f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(1.76f, 0.65f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(1.76f, 1.96, 0.50f, 0.65f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();
	glPopMatrix();


	//Index Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, 0.40f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.00f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.40f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, 0.40f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.50f, 0.40f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();


	//Middle Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, 0.25f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.00f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.25f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, 0.25f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.6f, 0.25f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();


	//Ring Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, 0.10f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.00f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.10f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, 0.10f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.55f, 0.10f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();


	//Little Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, -0.05f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, -0.00f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, -0.05f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, -0.05f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.45f, -0.05f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();

	glPopAttrib();
}
void rightHand() {
	whiteMaterial();
	glPushAttrib(1);
	//grey bar
	glColor3f(1, 1, 1);
	//Palm
	drawRecT(1.5f, 2.1f, -0.05f, 0.55f, 0.15f, 0.3f, GL_QUADS, 2);
	drawRecT(1.5f, 2.1f, -0.00f, 0.55f, 0.15f, 0.3f, GL_QUADS, 2);
	drawRecT(1.5f, 2.1f, -0.05f, 0.00f, 0.15f, 0.3f, GL_QUADS, 2);
	glPushMatrix();
	glTranslatef(0, -0.8, 0);
	glRotated(-90, 0, 0, 1);
	glTranslatef(-2.35, 1, 0);


	//Thumb
	drawPyramid(1.5, 1.7f, 0.55f, 0.65f, 0.2f, 0.3f, 1.08f, 2.0f, GL_TRIANGLES, GL_QUADS);
	glPushMatrix();
	glTranslatef(1.56f, 0.70f, 0.3f);
	glRotatef(42.0f, 0.0f, 0.0f, 0.5f);
	glTranslatef(-1.56f, -0.70f, -0.3f);
	//inner
	glTranslatef(1.56f, 0.65f, 0.3f);
	glRotatef(initialThumbMove, 0.0f, -0.5f, 0.0f);
	initialThumbMove += thumbMove;
	glTranslatef(-1.56f, -0.65f, -0.3f);
	if (initialThumbMove >= 45.0f) {

		initialThumbMove = 45.0f;
		thumbMove = 0.0f;

	}
	else if (initialThumbMove <= 0.0f) {

		initialThumbMove = 0.0f;
		thumbMove = 0.0f;

	}
	drawRecT(1.56f, 1.76f, 0.50f, 0.65f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(1.00f, 1.05f, 0.50f, 0.65f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(1.76f, 0.65f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(1.76f, 1.96, 0.50f, 0.65f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();
	glPopMatrix();

	//Index Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, 0.40f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.00f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.40f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	glColor3f(1, 1, 1);
	//middle
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, 0.40f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.5f, 0.40f, 0.52f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();


	//Middle Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, 0.25f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.00f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.25f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, 0.25f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.6f, 0.25f, 0.37f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();


	//Ring Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, 0.10f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.00f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, 0.10f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, 0.10f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.55f, 0.10f, 0.22f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();


	//Little Finger
	glPushMatrix();
	//inner
	adjustFingerMove(2.10f, 0.50f, 0.3f, 0.0f, 0.5f, 0.0f, 60.0f, 0.0f);
	drawRecT(2.00f, 2.17f, -0.05f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, -0.00f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	drawRecT(2.00f, 2.17f, -0.05f, 0.00f, 0.2f, 0.3f, GL_QUADS, 2);
	//middle
	adjustFingerMove(2.10f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.10f, 2.32f, -0.05f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	//outer
	adjustFingerMove(2.25f, 0.20f, 0.3f, 0.0f, 0.5f, 0.0f, 90.0f, 0.0f);
	drawRecT(2.25f, 2.45f, -0.05f, 0.07f, 0.2f, 0.3f, GL_QUADS, 2);
	glPopMatrix();

	glPopAttrib();
}
void adjustFingerMove(float tx, float ty, float tz, float rx, float ry, float rz, float maxA, float minA) {
	glTranslatef(tx, ty, tz);
	glRotatef(initialFingerMove, rx, -ry, rz);
	initialFingerMove += fingerMove;
	glTranslatef(-tx, -ty, -tz);

	if (initialFingerMove >= maxA) {

		initialFingerMove = maxA;
		fingerMove = 0.0f;

	}
	else if (initialFingerMove <= minA) {

		initialFingerMove = minA;
		fingerMove = minA;

	}
}
void drawLeftHand() {
	glPushMatrix(); {
		//!!!
		glTranslatef(-0.05, 0, 0.05f);


		//glLoadIdentity();
		glScalef(1.25, 1, 1.25);
		glTranslatef(-0.42, -0.45, 0.05);
		glRotatef(-90, 0.0f, 0.0f, 1.0f);
		glScalef(0.25, 0.25, 0.25);
		glTranslatef(-1.6f, 0.0f, 0.0f);

		//Left, Right to rotate
		glRotatef(-90, 1.0f, 0.0f, 0.0f);
		glRotatef(-initialArmRotate, 1.0f, 0.0f, 0.0f);

		initialArmRotate += armRotate;
		if (initialArmRotate > 20)
		{
			initialArmRotate = 20;
		}
		else if (initialArmRotate < -9.7)
		{
			initialArmRotate = -9.7;
		}


		glPushMatrix(); {
			glRotatef(5, 0.0, 1.0, 0.0);

			glPushAttrib(1);
			glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
			drawRecT(-1.5f, 0.0f, 0.1f, 0.4f, 0.1f, 0.4f, GL_QUADS, 3);

			//armor plate #right
			glPushMatrix(); {
				glScalef(4, 3, 2);
				glTranslatef(-0.2f, 0.08f, -0.02f);
				glRotatef(90, 0, 0, 1);
				drawArmorPlate();
			}glPopMatrix();
			//armor plate #left
			glPushMatrix(); {
				glScalef(3.3, 3, 2);
				glTranslatef(-0.2f, 0.08f, 0.25f);
				glRotatef(90, 0, 0, 1);
				drawArmorPlate();
			}glPopMatrix();

			//tied gold rope #1
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-0.6f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.6f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-0.6f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.6f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();

			//tied gold rope #2
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-0.7f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.7f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-0.7f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.7f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();

			//tied gold rope #3
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-1.0f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.0f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-1.0f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.0f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();

			//tied gold rope #4
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-1.1f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.1f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-1.1f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.1f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();
			glPopAttrib();

			glPushAttrib(1);
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			drawRecT(-0.8f, -1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
			drawRecT(-0.7f, -0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
			glPopAttrib();

			glPushAttrib(1);
			glColor3f(0, 0, 0);
			//drawRec(-1.5f, 0.0f, 0.1f, 0.4f, 0.1f, 0.4f, GL_LINE_LOOP);
			//drawRec(-0.8f, -1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
			//drawRec(-0.7f, -0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
			glPopAttrib();

			glPushAttrib(1);
			//crimson red
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			//glColor3f(1, 1, 1);
			//shoulder
			glPushMatrix(); {
				glScalef(1, 1.4, 1);
				glTranslatef(0, -0.1, 0);
				glRotatef(60, 0.0, 1.0, 0.0);
				glTranslatef(0.6, 0.0, -1.6);
				drawRecT(-1.0f, -1.9f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);

				//upper
				//armor playte #1
				glPushMatrix(); {
					glScalef(3.3, 3, 2);
					glTranslatef(-0.4f, 0.08f, -0.04f);
					glRotatef(90, 0, 0, 1);
					drawArmorPlate();
				}glPopMatrix();

				//armor playte #2
				glPushMatrix(); {
					glScalef(3.3, 3, 2);
					glTranslatef(-0.42f, 0.08f, -0.08f);
					glRotatef(90, 0, 0, 1);
					drawArmorPlate();
				}glPopMatrix();
				glPopAttrib();

				glPushAttrib(1);
				glColor3f(0, 0, 0);
				drawRec(-1.0f, -1.9f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				glPopAttrib();

				glPushAttrib(1);
				glColor3f(1, 1, 1);
				glPushMatrix(); {
					glTranslatef(-1.0, 0.5, 0.0);
					glRotatef(-90, 0.0, 0.0, 1.0);
					glRotatef(90, 1.0, 0.0, 1.0);
					drawPyramid(0, 0.5, 0, 0.5, 0.0, 0.5, 1, 2, GL_TRIANGLES, GL_QUADS);
					glPopAttrib();

					glPushAttrib(1);
					glColor3f(0, 0, 0);
					//drawPyramid(0, 0.5, 0, 0.5, 0.0, 0.5, 1, 2, GL_LINE_LOOP, GL_LINE_LOOP);
					glPopAttrib();
				}glPopMatrix();
			}glPopMatrix();
		}glPopMatrix();

		glPushMatrix(); {
			//Up, Down to move arm up down
			glRotatef(initialArmMove, 0.0f, 0.0f, 0.1f);
			initialArmMove += armMove;

			if (initialArmMove >= 60.0f) {

				initialArmMove = 60.0f;
				armMove = 0.0f;
			}
			else if (initialArmMove <= 0.0f) {

				initialArmMove = 0.0f;
				armMove = 0.0f;

			}
			glRotatef(initialLeftArmSpeed, 0.0f, 0.1f, 0.0f); //control lower arm

			initialLeftArmSpeed += leftArmSpeed;

			if (initialLeftArmSpeed >= leftArmMaxAngle) {
				initialLeftArmSpeed = leftArmMaxAngle;
				leftArmSpeed = 0.0f;
			}

			if (initialLeftArmSpeed <= leftArmMinAngle) {
				initialLeftArmSpeed = leftArmMinAngle;
				leftArmSpeed = 0.0f;
			}
			glPushMatrix(); {
				glRotatef(-5, 0.0, 1.0, 0.0);

				glPushAttrib(1);
				//grey bar
				glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
				drawRecT(0.0f, 1.5f, 0.1f, 0.4f, 0.1f, 0.4f, GL_QUADS, 3);
				glPopAttrib();

				glPushAttrib(1);
				//crimson red
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				drawRecT(0.8f, 1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
				drawRecT(0.7f, 0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
				drawRecT(0.8f, 1.5f, 0.0f, 0.1f, 0.0f, 0.1f, GL_QUADS, 1);
				glPopAttrib();

				glPushAttrib(1);
				glColor3f(0, 0, 0);
				//drawRec(0.0f, 1.5f, 0.1f, 0.4f, 0.1f, 0.4f, GL_LINE_LOOP);
				//drawRec(0.8f, 1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				//drawRec(0.7f, 0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				//drawRec(0.8f, 1.5f, 0.0f, 0.1f, 0.0f, 0.1f, GL_LINE_LOOP);
				glColor3f(1, 1, 1);
				glPopAttrib();

				//shield
				glPushMatrix(); {
					glRotatef(90.0f, 0.0f, -1.0f, 0.0f);
					glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
					glTranslatef(0.5, -0.65, -1.0);
					glScalef(2, 2, 2);
					glPushAttrib(1);
					//crimson red
					glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
					controlShield();
					glPopAttrib();

					if (isWeaponOn) {
						//glScalef(0.5, 2, 0.5);
						glRotatef(90, 1, 0, 0);
						glTranslatef(-0.1, -0.2, -0.4);
						glBindTexture(GL_TEXTURE_2D, whiteTextures);
						glBegin(GL_TRIANGLES);
						glTexCoord2f(0.3f, 0.3f);	glVertex2f(0.19, 0.0);

						glTexCoord2f(0.3f, -0.3f);glVertex2f(-0.19, 0.0);
						glTexCoord2f(-0.3f, -0.3f);glVertex2f(0.0, -1.5);

						glEnd();
					}
					glPopMatrix();
				}


				//joint
				glPushMatrix(); {
					glTranslatef(0.0, 0.25, 0.25);
					glPushAttrib(1);
					//grey bar
					glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
					drawSphere(0.25, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					glTranslatef(1.5, 0.25, 0.25);
					drawSphere(0.15, GL_FILL);
					glPopAttrib();
				}glPopMatrix();

				leftHand();
			}glPopMatrix();
		}glPopMatrix();

	}glPopMatrix();

}
void drawRightHand() {
	glPushMatrix(); {
		//!!!

		glTranslatef(0.05, 0, 0.05f);

		//glLoadIdentity();
		glScalef(1.25, 1, 1.25);
		glTranslatef(0.42, -0.45, -0.05);
		glRotatef(-90, 0.0f, 0.0f, 1.0f);
		glScalef(0.25, 0.25, 0.25);
		glTranslatef(-1.6f, 0.0f, 0.0f);
		//Left, Right to rotate
		glRotatef(90, 1.0f, 0.0f, 0.0f);
		glRotatef(initialArmRotate1, 1.0f, 0.0f, 0.0f);


		initialArmRotate1 += armRotate1;
		if (initialArmRotate1 > 12)
		{
			initialArmRotate1 = 12;

		}
		else if (initialArmRotate1 < -12)
		{
			initialArmRotate1 = -12;
		}


		glPushMatrix(); {
			glRotatef(5, 0.0, 1.0, 0.0);

			glPushAttrib(1);
			glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
			drawRecT(-1.5f, 0.0f, 0.1f, 0.4f, 0.1f, 0.4f, GL_QUADS, 3);
			glPopAttrib();

			//armor plate #right
			glPushMatrix(); {
				glScalef(4, 3, 2);
				glTranslatef(-0.2f, 0.08f, -0.02f);
				glRotatef(90, 0, 0, 1);
				drawArmorPlate();
			}glPopMatrix();
			//armor plate #left
			glPushMatrix(); {
				glScalef(3.3, 3, 2);
				glTranslatef(-0.2f, 0.08f, 0.25f);
				glRotatef(90, 0, 0, 1);
				drawArmorPlate();
			}glPopMatrix();

			//tied gold rope #1
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-0.6f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.6f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-0.6f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.6f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();

			//tied gold rope #2
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-0.7f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.7f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-0.7f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-0.7f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();

			//tied gold rope #3
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-1.0f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.0f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-1.0f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.0f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();

			//tied gold rope #4
			glPushMatrix(); {
				glPushMatrix(); {
					//front
					glTranslatef(-1.1f, 0.55f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.1f, 0.55f, -0.05f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//back
					glTranslatef(-1.1f, -0.05f, -0.05f);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

				glPushMatrix(); {
					//side
					glTranslatef(-1.1f, 0.55f, 0.57f);
					glRotatef(90, 1, 0, 0);
					drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
				}glPopMatrix();

			}glPopMatrix();



			glPushAttrib(1);
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			drawRecT(-0.8f, -1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
			drawRecT(-0.7f, -0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
			glPopAttrib();

			glPushMatrix(); {
				glPushAttrib(1);
				glColor3f(0, 0, 0);
				//drawRec(-1.5f, 0.0f, 0.1f, 0.4f, 0.1f, 0.4f, GL_LINE_LOOP);
				//drawRec(-0.8f, -1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				//drawRec(-0.7f, -0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				glPopAttrib();

			}glPopMatrix();

			glPushAttrib(1);
			//crimson red
			glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
			//glColor3f(1, 1, 1);
			//shoulder
			glPushMatrix(); {
				glScalef(1, 1.4, 1);
				glTranslatef(0, -0.1, 0);
				glRotatef(60, 0.0, 1.0, 0.0);
				glTranslatef(0.6, 0.0, -1.6);
				drawRecT(-1.0f, -1.9f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);

				//upper
			//armor playte #1
				glPushMatrix(); {
					glScalef(3.3, 3, 2);
					glTranslatef(-0.4f, 0.08f, -0.04f);
					glRotatef(90, 0, 0, 1);
					drawArmorPlate();
				}glPopMatrix();

				//armor playte #2
				glPushMatrix(); {
					glScalef(3.3, 3, 2);
					glTranslatef(-0.42f, 0.08f, -0.08f);
					glRotatef(90, 0, 0, 1);
					drawArmorPlate();
				}glPopMatrix();
				glPopAttrib();

				glPushAttrib(1);
				glColor3f(0, 0, 0);
				//drawRec(-1.0f, -1.9f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				glPopAttrib();

				glPushAttrib(1);
				//crimson red
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				glPushMatrix(); {
					glTranslatef(-1.0, 0.5, 0.0);
					glRotatef(-90, 0.0, 0.0, 1.0);
					glRotatef(90, 1.0, 0.0, 1.0);
					drawPyramid(0, 0.5, 0, 0.5, 0.0, 0.5, 1, 2, GL_TRIANGLES, GL_QUADS);
					glPopAttrib();

					glPushAttrib(1);
					glColor3f(0, 0, 0);
					//drawPyramid(0, 0.5, 0, 0.5, 0.0, 0.5, 1, 2, GL_LINE_LOOP, GL_LINE_LOOP);
					glPopAttrib();
				}glPopMatrix();
			}glPopMatrix();

		}glPopMatrix();

		glPushMatrix(); {
			//Up, Down to move arm up down
			glRotatef(-initialArmMove1, 0.0f, 0.0f, 0.1f);
			initialArmMove1 += armMove1;
			if (initialArmMove1 >= 120.0f) {
				initialArmMove1 = 120.0f;
				armMove1 = 0.0f;
			}
			else if (initialArmMove1 <= 0.0f) {
				initialArmMove1 = 0.0f;
				armMove1 = 0.0f;
			}
			glRotatef(initialRightArmSpeed, 0.0f, 0.1f, 0.0f); //control lower arm
			initialRightArmSpeed += rightArmSpeed;

			if (initialRightArmSpeed >= rightArmMaxAngle) {
				initialRightArmSpeed = rightArmMaxAngle;
				rightArmSpeed = 0.0f;
			}

			if (initialRightArmSpeed <= rightArmMinAngle) {
				initialRightArmSpeed = rightArmMinAngle;
				rightArmSpeed = 0.0f;
			}
			glPushMatrix(); {
				glRotatef(-5, 0.0, 1.0, 0.0);

				glPushAttrib(1);
				//grey bar
				glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
				drawRecT(0.0f, 1.5f, 0.1f, 0.4f, 0.1f, 0.4f, GL_QUADS, 3);
				glPopAttrib();

				glPushAttrib(1);
				//crimson red
				glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
				drawRecT(0.8f, 1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
				drawRecT(0.7f, 0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_QUADS, 1);
				drawRecT(0.8f, 1.5f, 0.0f, 0.1f, 0.0f, 0.1f, GL_QUADS, 1);
				glPopAttrib();

				glPushAttrib(1);
				glColor3f(0, 0, 0);
				//drawRec(0.0f, 1.5f, 0.1f, 0.4f, 0.1f, 0.4f, GL_LINE_LOOP);
				//drawRec(0.8f, 1.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				//drawRec(0.7f, 0.2f, 0.0f, 0.5f, 0.0f, 0.5f, GL_LINE_LOOP);
				//drawRec(0.8f, 1.5f, 0.0f, 0.1f, 0.0f, 0.1f, GL_LINE_LOOP);
				glPopAttrib();

				//shield
				glPushMatrix(); {
					glRotatef(90.0f, 0.0f, -1.0f, 0.0f);
					glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
					glTranslatef(0.5, -0.65, -1.0);
					glScalef(2, 2, 2);
					glPushAttrib(1);
					glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
					controlShield();
					glPopAttrib();
				}glPopMatrix();

				//joint
				glPushMatrix(); {
					glTranslatef(0.0, 0.25, 0.25);
					glPushAttrib(1);
					//grey bar
					glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
					glPushMatrix(); {
						glRotatef(180, 1, 0, 0);
						drawSphere(0.25, GL_FILL);
					}glPopMatrix();

				}glPopMatrix();

				glPushMatrix(); {
					glTranslatef(1.5, 0.25, 0.25);
					drawSphere(0.15, GL_FILL);
					glPopAttrib();
				}glPopMatrix();

				rightHand();
			}glPopMatrix();

		}glPopMatrix();
	}glPopMatrix();
}
void DrawHandle() {
	grayMaterial();
	glPushAttrib(1);
	glColor3f(1, 1, 1);

	glPushMatrix();
	//glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
	drawRecT(0.0f, 0.3f, 0.0f, 0.05f, 0.0f, 0.05f, GL_QUADS, 4);
	drawRecT(0.0f, 0.3f, 0.0f, 0.00f, 0.0f, 0.05f, GL_QUADS, 4);
	glPopMatrix();

	glPushMatrix();
	glRotatef(60.0f, 0.0f, 0.0f, -1.0f);
	glTranslatef(-0.2f, 0.0f, 0.0f);

	drawRecT(0.0f, 0.2f, 0.0f, 0.05f, 0.0f, 0.05f, GL_QUADS, 4);
	drawRecT(0.0f, 0.2f, 0.0f, 0.00f, 0.0f, 0.05f, GL_QUADS, 4);

	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.3f, 0.0f, 0.0f);
	glRotatef(60.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-0.3f, -0.0f, -0.0f);

	glTranslatef(0.3f, 0.0f, 0.0f);

	drawRecT(0.0f, 0.2f, 0.0f, 0.05f, 0.0f, 0.05f, GL_QUADS, 4);
	drawRecT(0.0f, 0.2f, 0.0f, 0.00f, 0.0f, 0.05f, GL_QUADS, 4);

	glPopMatrix();
	glPopAttrib();
}
void DrawShield() {
	glPushMatrix();
	goldMaterial();
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glTranslatef(0.15f, 0.0f, 0.2f);
	glScalef(2.0f, 2.0f, 2.0f);

	shieldPentagon(0.0f, 0.04f, GL_POLYGON, GL_QUADS);

	glColor3f(0, 0, 0);
	shieldPentagon(0.0f, 0.04f, GL_LINE_LOOP, GL_LINE_LOOP);
	glColor3f(1, 1, 1);
	glPopMatrix();
}
void shieldPentagon(float minZ, float maxZ, GLenum type1, GLenum type2) {
	glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
	glBegin(type1);
	//glTexCoord2f(-0.1f, minZ);
	glTexCoord2f(0.3f, 0.3f);	glVertex3f(-0.1f, 0.2f, minZ);
	//glTexCoord2f(0.1f, minZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, 0.2f, minZ);
	//glTexCoord2f(0.16f, minZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.16f, -0.09f, minZ);
	//glTexCoord2f(0.0f, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.25f, minZ);
	//glTexCoord2f(-0.16f, minZ);
	glVertex3f(-0.16f, -0.09f, minZ);
	glEnd();

	glBegin(type1);
	//glTexCoord2f(-0.1f, maxZ);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, maxZ);
	//glTexCoord2f(0.1f, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, 0.2f, maxZ);
	//glTexCoord2f(0.16f, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.16f, -0.09f, maxZ);
	//glTexCoord2f(0.0f, maxZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.25f, maxZ);
	//glTexCoord2f(-0.16f, maxZ);
	glVertex3f(-0.16f, -0.09f, maxZ);
	glEnd();

	glBegin(type2);
	//glTexCoord2f(-0.16f, minZ);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.16f, -0.09f, minZ);
	//glTexCoord2f(0.0f, minZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.0f, -0.25f, minZ);
	//glTexCoord2f(0.0f, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.0f, -0.25f, maxZ);
	//glTexCoord2f(-0.16f, maxZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.16f, -0.09f, maxZ);
	glEnd();

	glBegin(type2);
	//glTexCoord2f(-0.16f, minZ);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.16f, -0.09f, minZ);
	//glTexCoord2f(-0.16f, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.16f, -0.09f, maxZ);
	//glTexCoord2f(-0.1f, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.1f, 0.2f, maxZ);
	//glTexCoord2f(-0.1f, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, minZ);
	glEnd();

	glBegin(type2);
	//glTexCoord2f(-0.1f, minZ);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.1f, 0.2f, minZ);
	//glTexCoord2f(-0.1f, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.1f, 0.2f, maxZ);
	//glTexCoord2f(0.1f, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.1f, 0.2f, maxZ);
	//glTexCoord2f(0.1f, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.1f, 0.2f, minZ);
	glEnd();

	glBegin(type2);
	//glTexCoord2f(0.1f, minZ);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0.1f, 0.2f, minZ);
	//glTexCoord2f(0.1f, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.1f, 0.2f, maxZ);
	//glTexCoord2f(0.16f, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.16f, -0.09f, maxZ);
	//glTexCoord2f(0.16f, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.16f, -0.09f, minZ);
	glEnd();

	glBegin(type2);
	//glTexCoord2f(0.16f, minZ);
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0.16f, -0.09f, minZ);
	//glTexCoord2f(0.16f, maxZ);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0.16f, -0.09f, maxZ);
	//glTexCoord2f(0.0f, maxZ);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.0f, -0.25f, maxZ);
	//glTexCoord2f(0.0f, minZ);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.0f, -0.25f, minZ);
	glEnd();

}
void controlShield() {

	glPushMatrix();
	glTranslatef(-0.2, 0.23f, -0.15f);
	glScalef(0.65f, 0.65f, 0.65f);

	DrawHandle();
	DrawShield();
	glPopMatrix();

}
//------------------------LEG ---------------------------------
void drawFillSphere(double radius) {
	GLUquadricObj* sphere = NULL;
	sphere = gluNewQuadric();
	gluQuadricDrawStyle(sphere, GLU_FILL);	//GLU_FILL, GLU_LINE, GLU_POINT?
	glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
	gluQuadricTexture(sphere, GL_TRUE);
	gluSphere(sphere, radius, 30, 30);
	gluDeleteQuadric(sphere);
}
void drawFillCylinder(double baseRadius, double topRadius, double height, int texture) {
	GLUquadricObj* cylinder = NULL;
	cylinder = gluNewQuadric();
	gluQuadricDrawStyle(cylinder, GLU_FILL);
	if (texture == 1) {
		glBindTexture(GL_TEXTURE_2D, BodyTextures);
	}
	else if (texture == 2) {
		glBindTexture(GL_TEXTURE_2D, flameTextures);
	}

	gluQuadricTexture(cylinder, GL_TRUE);
	gluCylinder(cylinder, baseRadius, topRadius, height, 30, 30);
	gluDeleteQuadric(cylinder);
}
void drawCuboid(float length, float height, float width) {
	glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
	glBegin(GL_QUADS);

	//Face 1 : Front 
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, 0);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(length, height, 0);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, 0);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0, 0, 0);

	//Face 2 : Right 
	glTexCoord2f(0.3f, 0.3f);glVertex3f(length, height, 0);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(length, height, width);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, width);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(length, 0, 0);

	//Face 3 : Left 
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, 0);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0, height, width);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(0, 0, width);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0, 0, 0);

	//Face 4 : Back 
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, width);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(length, height, width);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, width);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(0, 0, width);

	//Face 5 : Top 
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, 0);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0, height, width);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, height, width);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(length, height, 0);

	//Face 6 : Bottom 
	glTexCoord2f(0.3f, 0.3f);glVertex3f(0, 0, 0);
	glTexCoord2f(0.3f, -0.3f);glVertex3f(0, 0, width);
	glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, width);
	glTexCoord2f(-0.3f, 0.3f);glVertex3f(length, 0, 0);

	glEnd();
}
void drawRightAngleTriangle(float length, float height, float width) {
	glPushMatrix(); {
		glRotatef(-90, 1, 0, 0);
		glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
		glBegin(GL_POLYGON);

		//FACE 1 : FRONT 
		glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, width / 2);
		glTexCoord2f(0.3f, -0.3f);glVertex3f(0, 0, width / 2);
		glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, width / 2);

		//FACE 2 : BOTTOM 
		glTexCoord2f(0.3f, 0.3f);glVertex3f(0, 0, width / 2);
		glTexCoord2f(0.3f, -0.3f);glVertex3f(0, 0, -(width / 2));
		glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, -(width / 2));
		glTexCoord2f(-0.3f, 0.3f);glVertex3f(length, 0, width / 2);

		//FACE 3 : TOP 
		glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, width / 2);
		glTexCoord2f(0.3f, -0.3f);glVertex3f(0, height, -(width / 2));
		glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, -(width / 2));
		glTexCoord2f(-0.3f, 0.3f);glVertex3f(length, 0, width / 2);

		//FACE 4 : LEFT 
		glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, width / 2);
		glTexCoord2f(0.3f, -0.3f);glVertex3f(0, 0, width / 2);
		glTexCoord2f(-0.3f, -0.3f);glVertex3f(0, 0, -(width / 2));
		glTexCoord2f(-0.3f, 0.3f);glVertex3f(0, height, -(width / 2));

		//FACE 5 : BACK 
		glTexCoord2f(0.3f, 0.3f);glVertex3f(0, height, -(width / 2));
		glTexCoord2f(0.3f, -0.3f);glVertex3f(0, 0, -(width / 2));
		glTexCoord2f(-0.3f, -0.3f);glVertex3f(length, 0, -(width / 2));

		glEnd();
	} glPopMatrix();

}
void drawCubeLine(float length, float height, float width, float lineWidth) {
	glLineWidth(lineWidth);
	glBegin(GL_LINE_LOOP);
	// Face 1 / Bottom
	glVertex3f(0.0f, 0.0f, width);
	glVertex3f(length, 0.0f, width);
	glVertex3f(length, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glEnd();
	// Face 2 / Left
	glBegin(GL_LINE_LOOP);
	glVertex3f(0, 0.0f, 0.0f);
	glVertex3f(0.0f, height, 0.0f);
	glVertex3f(0.0f, height, width);
	glVertex3f(0, 0, width);
	glEnd();
	// Face 3 / Front
	glBegin(GL_LINE_LOOP);
	glVertex3f(0.0f, 0.0f, 0);
	glVertex3f(0.0f, height, 0);
	glVertex3f(length, height, 0);
	glVertex3f(length, 0.0f, 0);
	glEnd();
	// Face 4 / Right
	glBegin(GL_LINE_LOOP);
	glVertex3f(length, 0.0f, 0);
	glVertex3f(length, height, 0);
	glVertex3f(length, height, width);
	glVertex3f(length, 0.0f, width);
	glEnd();
	// Face 5 / Back
	glBegin(GL_LINE_LOOP);
	glVertex3f(0, 0.0f, width);
	glVertex3f(0.0f, height, width);
	glVertex3f(length, height, width);
	glVertex3f(length, 0, width);
	glEnd();
	// Face 6 / Top
	glBegin(GL_LINE_LOOP);
	glVertex3f(0, height, 0.0f);
	glVertex3f(length, height, 0.0f);
	glVertex3f(length, height, width);
	glVertex3f(0, height, width);
	glEnd();
}
//lower body 
void drawLowerBody(GLUquadricObj* object) {

	glPushMatrix(); {
		glTranslatef(0.25f, 1.25f, 1.56f);
		drawPelvis(object);
	}glPopMatrix();

	if (walking) {
		walk();
	}
	if (running) {
		run();
	}

	glPushMatrix(); {
		glTranslatef(-0.25f, 0, 0.3);
		drawLeftLeg();
	}glPopMatrix();

	glPushMatrix(); {
		glTranslatef(0.25f, 0, 0.3);
		drawRightLeg();
	}glPopMatrix();

}
void walk() {
	if (rightLegForward) {		//if right leg forward --> left leg push to front, right to back 
		if (leftWalkingHipsAndThighAngle <= 15) {
			leftWalkingHipsAndThighAngle += 0.5;
			rotateHead += 0.5f;
			rotateBody -= 0.5f;
			rotateLowerBody += 0.5f;
		}

		if (leftWalkingThighAndCalfAngle <= 10) {
			leftWalkingThighAndCalfAngle += 0.5;

		}

		if (rightWalkingHipsAndThighAngle <= 15) {
			rightWalkingHipsAndThighAngle += 0.5;
		}

		if (rightWalkingThighAndCalfAngle <= 10) {
			rightWalkingThighAndCalfAngle += 0.5;
		}

		if (leftWalkingHipsAndThighAngle >= 15 && leftWalkingThighAndCalfAngle >= 10) {
			rightLegForward = false;
		}
	}
	else {		//if right leg backward --> left leg push to back, right to front 
		if (leftWalkingHipsAndThighAngle >= -15) {
			leftWalkingHipsAndThighAngle -= 0.5;
			rotateHead -= 0.5f;
			rotateBody += 0.5f;
			rotateLowerBody -= 0.5f;
		}

		if (leftWalkingThighAndCalfAngle <= 10) {
			leftWalkingThighAndCalfAngle -= 0.5;
		}

		if (rightWalkingHipsAndThighAngle >= -15) {
			rightWalkingHipsAndThighAngle -= 0.5;
		}

		if (rightWalkingThighAndCalfAngle <= 10) {
			rightWalkingThighAndCalfAngle -= 0.5;
		}

		if (rightWalkingHipsAndThighAngle <= -15 && rightWalkingThighAndCalfAngle >= 10) {
			rightLegForward = true;
		}
	}
}
void walkingFront() {
	if (walkFrontAngle >= 0) {
		walkFrontAngle += 0.01;
	}
	glTranslatef(0, -walkFrontAngle, 0);
}
void run() {
	if (runningRightLegForward) {		//if right leg forward --> left leg push to front, right to back 
		if (leftRunningHipsAndThighAngle <= 35) {
			leftRunningHipsAndThighAngle += 2;
			rotateHead += 0.65f;
			rotateBody -= 0.65f;
			rotateLowerBody += 0.65f;
		}

		if (leftRunningThighAndCalfAngle <= 30) {
			leftRunningThighAndCalfAngle += 2;
		}

		if (rightRunningHipsAndThighAngle <= 35) {
			rightRunningHipsAndThighAngle += 2;
		}

		if (rightRunningThighAndCalfAngle <= 30) {
			rightRunningThighAndCalfAngle += 2;
		}

		if (leftRunningHipsAndThighAngle >= 35 && leftRunningThighAndCalfAngle >= 30) {
			runningRightLegForward = false;
		}
	}
	else {		//if right leg backward --> left leg push to back, right to front 
		if (leftRunningHipsAndThighAngle >= -35) {
			leftRunningHipsAndThighAngle -= 2;
			rotateHead -= 0.65f;
			rotateBody += 0.65f;
			rotateLowerBody -= 0.65f;
		}

		if (leftRunningThighAndCalfAngle <= 30) {
			leftRunningThighAndCalfAngle -= 2;
		}

		if (rightRunningHipsAndThighAngle >= -35) {
			rightRunningHipsAndThighAngle -= 2;
		}

		if (rightRunningThighAndCalfAngle <= 30) {
			rightRunningThighAndCalfAngle -= 2;
		}

		if (rightRunningHipsAndThighAngle <= -35 && rightRunningThighAndCalfAngle >= 30) {
			runningRightLegForward = true;
		}
	}
}
void runningFront() {
	if (runFrontAngle >= 0) {
		runFrontAngle += 0.03;
	}
	glTranslatef(0, -runFrontAngle, 0);
}
void fly() {
	glRotatef(10, 1, 0, 0);
	glTranslatef(0, flyAngleZ, flyAngleY);  //x (+ve right), z (+ve backward), y (+ve up)

	if (flyingThighAndCalfAngle <= 15) {
		flyingThighAndCalfAngle += 3;
	}

	if (flyingHipsAndThighAngle >= 30) {
		flyingHipsAndThighAngle -= 0.05;
	}
}
void fire() {
	if (flyingCylinderHeight <= 0.2) {
		flyingCylinderHeight += 0.02;
	}

	if (flyingFireHeight <= 1.2) {
		flyingFireHeight += 0.04;
	}
}
//pelvis 
void drawPelvis(GLUquadricObj* object) {
	glPushMatrix(); {
		redMaterial();
		glScalef(0.5, 0.5, 0.5);
		glPushAttrib(1);
		//crimson red
		glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
		//middle
		glPushMatrix(); {
			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glRotatef(90, 1, 0, 0);
			//front
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 3.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 1.0f, 3.5f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 1.0f, 3.5f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 3.0f);
			glEnd();

			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 1.0f, 3.5f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, -1.0f, 2.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 2.0f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, 1.0f, 3.5f);
			glEnd();

			//back
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 2.0f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.5f, -1.0f, 1);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, -1.0f, 1);
			glEnd();

			//under
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 1);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 1);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 2);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 2);
			glEnd();

			//up
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 0);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 3);
			glEnd();

			//side
			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.5f, 1.0f, 3.5);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 2.0f);
			glVertex3f(0.5f, -1.0f, 1.0f);
			glEnd();

			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 1.0f, 3.5);
			glVertex3f(-0.5f, -1.0f, 2.0f);
			glVertex3f(-0.5f, -1.0f, 1.0f);
			glEnd();
		}glPopMatrix();

		//mid JOINT
		glPushMatrix(); {
			glTranslatef(0, -6.5f, -3.5f);
			glScalef(25, 8, 8);
			drawBallJoint(object);
		}glPopMatrix();

		//right
		glPushMatrix(); {
			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glTranslatef(1.5f, 0.0f, 3.5f);
			glRotatef(90, 1, 0, 0);
			glRotatef(135, 0, 0, 1);
			//front
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 3.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 1.0f, 3.5f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 1.0f, 3.5f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 3.0f);
			glEnd();

			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 1.0f, 3.5f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, -1.0f, 2.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 2.0f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, 1.0f, 3.5f);
			glEnd();

			//back
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 2.0f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.5f, -1.0f, 1);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, -1.0f, 1);
			glEnd();

			//under
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 1);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 1);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 2);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 2);
			glEnd();

			//up
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 0);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 3);
			glEnd();

			//side
			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.5f, 1.0f, 3.5);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 2.0f);
			glVertex3f(0.5f, -1.0f, 1.0f);
			glEnd();

			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 1.0f, 3.5);
			glVertex3f(-0.5f, -1.0f, 2.0f);
			glVertex3f(-0.5f, -1.0f, 1.0f);
			glEnd();
		}glPopMatrix();

		//left
		glPushMatrix(); {
			glBindTexture(GL_TEXTURE_2D, BodyTextures);
			glTranslatef(-1.5f, 0.0f, 3.5f);
			glRotatef(90, 1, 0, 0);
			glRotatef(-135, 0, 0, 1);
			//front
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 3.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 1.0f, 3.5f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 1.0f, 3.5f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 3.0f);
			glEnd();

			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 1.0f, 3.5f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, -1.0f, 2.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 2.0f);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, 1.0f, 3.5f);
			glEnd();

			//back
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 0.0f);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 2.0f, 0.0f);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.5f, -1.0f, 1);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(-0.5f, -1.0f, 1);
			glEnd();

			//under
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 1);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 1);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, -1.0f, 2);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 2);
			glEnd();

			//up
			glBegin(GL_QUADS);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 0);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 3);
			glEnd();

			//side
			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(0.5f, 1.0f, 3.5);
			glTexCoord2f(-0.3f, 0.3f);glVertex3f(0.5f, -1.0f, 2.0f);
			glVertex3f(0.5f, -1.0f, 1.0f);
			glEnd();

			glBegin(GL_POLYGON);
			glTexCoord2f(0.3f, 0.3f);glVertex3f(-0.5f, 2.0f, 0);
			glTexCoord2f(0.3f, -0.3f);glVertex3f(-0.5f, 2.0f, 3);
			glTexCoord2f(-0.3f, -0.3f);glVertex3f(-0.5f, 1.0f, 3.5);
			glVertex3f(-0.5f, -1.0f, 2.0f);
			glVertex3f(-0.5f, -1.0f, 1.0f);
			glEnd();
		}glPopMatrix();
		glPopAttrib();

		//armor plate
		glPushAttrib(1);
		//green
		glColor3f(26 / 255.0f, 163 / 255.0f, 109 / 255.0f);
		glPushMatrix(); {
			glScalef(18, 18, 18);
			glTranslatef(0, 0.03f, 0.05f);
			glRotatef(100, 1, 0, 0);

			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(10, 10, 10);
			glTranslatef(0.225f, -0.1f, 0.25f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 0, 0, 1);
			glRotatef(40, 0, 1, 0);
			glRotatef(-16, 1, 0, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(10, 10, 10);
			glTranslatef(-0.25f, -0.1f, 0.25f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 0, 0, 1);
			glRotatef(-40, 0, 1, 0);
			glRotatef(16, 1, 0, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(10, 10, 10);
			glTranslatef(0.225f, -0.3f, 0.25f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 0, 0, 1);
			glRotatef(-45, 0, 1, 0);
			glRotatef(-16, 1, 0, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(10, 10, 10);
			glTranslatef(-0.25f, -0.3f, 0.25f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 0, 0, 1);
			glRotatef(40, 0, 1, 0);
			glRotatef(16, 1, 0, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(18, 18, 18);
			glTranslatef(0.17f, -0.1f, 0.07f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 0, 0, 1);
			//glRotatef(30, 0, 1, 0);
			glRotatef(-16, 1, 0, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(18, 18, 18);
			glTranslatef(-0.2f, -0.1f, 0.07f);
			glRotatef(90, 0, 1, 0);
			glRotatef(90, 0, 0, 1);
			//glRotatef(-30, 0, 1, 0);
			glRotatef(16, 1, 0, 0);
			drawArmorPlate();
		}glPopMatrix();

		glPushMatrix(); {
			glScalef(20, 18, 15);
			glTranslatef(0, -0.2f, 0.1f);
			glRotatef(80, 1, 0, 0);

			drawArmorPlate();
		}glPopMatrix();

		glPopAttrib();

	}glPopMatrix();

}
//legs
void drawLeftLeg() {
	glPushMatrix(); {
		glColor3f(0.38, 0.38, 0.38);

		if (walking) {
			glTranslatef(0, 0, 1);
			glRotatef(-leftWalkingHipsAndThighAngle, 1, 0, 0);
			glTranslatef(0, 0, -1);
		}

		if (running) {
			glTranslatef(0, 0, 1.5);
			glRotatef(-leftRunningHipsAndThighAngle, 1, 0, 0);
			glTranslatef(0, 0, -1.5);
		}

		if (flying) {
			glTranslatef(0, 0, 1);
			glRotatef(-flyingHipsAndThighAngle, 1, 0, 0);
			glTranslatef(0, 0, -1);
		}

		glPushMatrix(); {
			//ball joint -- hips to thigh 
			glPushMatrix(); {
				glTranslatef(-0.3, 0.4, 1.5);
				drawJointHipsToThigh();
			} glPopMatrix();

			//thigh 
			glPushMatrix(); {
				glTranslatef(-0.3, 0.4, -1.8);
				drawThigh();
				glColor3f(0.38, 0.38, 0.38);

				//drawThighArmor
				glPushMatrix(); {
					glTranslatef(-0.4f, 0.1f, 1.5f);
					glRotatef(90, 1, 0, 0);
					glRotatef(-80, 0, 1, 0);
					glScalef(5, 8, 4);
					drawArmorPlate();
				}glPopMatrix();

				glPushMatrix(); {
					glTranslatef(0.4f, 0.1f, 1.5f);
					glRotatef(90, 1, 0, 0);
					glRotatef(90, 0, 1, 0);
					glScalef(5, 8, 4);
					drawArmorPlate();
				}glPopMatrix();

				glPushMatrix(); {
					glTranslatef(0, -0.5f, 1.5f);
					glRotatef(90, 1, 0, 0);
					glScalef(4, 8, 4);
					drawArmorPlate();
				}glPopMatrix();

				//tied gold rope #1
				glPushMatrix(); {
					glScalef(1.8, 2, 2);
					glRotatef(90, 0, 1, 0);
					glTranslatef(-0.7f, -0.25, -0.28f);
					glPushMatrix(); {
						//front
						glTranslatef(-0.6f, 0.55f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, -0.05f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//back
						glTranslatef(-0.6f, -0.1f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, 0.57f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();
				}glPopMatrix();

				//tied gold rope #2
				glPushMatrix(); {
					glScalef(1.8, 2, 2);
					glRotatef(90, 0, 1, 0);
					glTranslatef(-0.6f, -0.25, -0.28f);
					glPushMatrix(); {
						//front
						glTranslatef(-0.6f, 0.55f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, -0.05f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//back
						glTranslatef(-0.6f, -0.1f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, 0.57f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();
				}glPopMatrix();

				//tied gold rope #3
				glPushMatrix(); {
					glScalef(1.8, 2, 2);
					glRotatef(90, 0, 1, 0);
					glTranslatef(0.3f, -0.25, -0.28f);
					glPushMatrix(); {
						//front
						glTranslatef(-0.6f, 0.55f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, -0.05f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//back
						glTranslatef(-0.6f, -0.1f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, 0.57f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();
				}glPopMatrix();

				//tied gold rope #4
				glPushMatrix(); {
					glScalef(1.8, 2, 2);
					glRotatef(90, 0, 1, 0);
					glTranslatef(0.4f, -0.25, -0.28f);
					glPushMatrix(); {
						//front
						glTranslatef(-0.6f, 0.55f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, -0.05f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//back
						glTranslatef(-0.6f, -0.1f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, 0.57f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();
				}glPopMatrix();

			} glPopMatrix();
		}glPopMatrix();

		//ball joint -- thigh to calf 
		glPushMatrix(); {
			glTranslatef(-0.3, 0.4, -2.1);
			if (walking) {
				glRotatef(leftWalkingThighAndCalfAngle, 1, 0, 0);
			}
			if (running) {
				glRotatef(leftRunningThighAndCalfAngle, 1, 0, 0);
			}
			if (flying) {
				glRotatef(flyingThighAndCalfAngle, 1, 0, 0);
			}
			drawJointThighToCalf();
			glColor3f(0.38, 0.38, 0.38);

			//drawKneeArmor();


			//calf 
			glPushMatrix(); {
				glTranslatef(0, 0, -2.5);
				drawCalf();
				glColor3f(0.38, 0.38, 0.38);
				//drawCalfArmor

				glPushMatrix(); {
					glTranslatef(-0.35f, 0.1f, 1.2f);
					glRotatef(90, 1, 0, 0);
					glRotatef(-80, 0, 1, 0);
					glRotatef(3, 1, 0, 0);
					glScalef(4, 5, 4);
					drawArmorPlate();
				}glPopMatrix();

				glPushMatrix(); {
					glTranslatef(0.35f, 0.1f, 1.2f);
					glRotatef(90, 1, 0, 0);
					glRotatef(90, 0, 1, 0);
					glRotatef(3, 1, 0, 0);
					glScalef(4, 5, 4);
					drawArmorPlate();
				}glPopMatrix();

				glPushMatrix(); {
					glTranslatef(0, -0.35f, 1.2f);
					glRotatef(93, 1, 0, 0);
					glScalef(3, 5, 4);
					drawArmorPlate();
				}glPopMatrix();

				//tied gold rope #1
				glPushMatrix(); {
					glScalef(1.5, 1.6, 1.6);
					glRotatef(90, 0, 1, 0);
					glTranslatef(0.3f, -0.24, -0.28f);
					glPushMatrix(); {
						//front
						glTranslatef(-0.6f, 0.55f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, -0.05f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//back
						glTranslatef(-0.6f, -0.1f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, 0.57f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();
				}glPopMatrix();

				//tied gold rope #2
				glPushMatrix(); {
					glScalef(1.5, 1.6, 1.6);
					glRotatef(90, 0, 1, 0);
					glTranslatef(0.4f, -0.24, -0.28f);
					glPushMatrix(); {
						//front
						glTranslatef(-0.6f, 0.55f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, -0.05f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//back
						glTranslatef(-0.6f, -0.1f, -0.05f);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();

					glPushMatrix(); {
						//side
						glTranslatef(-0.6f, 0.55f, 0.57f);
						glRotatef(90, 1, 0, 0);
						drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
					}glPopMatrix();
				}glPopMatrix();
			}glPopMatrix();

			//square joint -- calf to foot 
			glPushMatrix(); {
				glTranslatef(-0.25f, -0.2f, -3.0);
				drawJointCalfToFoot();
			} glPopMatrix();

			//foot 
			glPushMatrix(); {
				glTranslatef(0, -0.22f, -3.2);
				drawFootR();
				//	glColor3f(0.38, 0.38, 0.38);
				drawFootArmor();
			} glPopMatrix();

		} glPopMatrix();
	}glPopMatrix();
}
void drawRightLeg() {
	glPushMatrix(); {
		glTranslatef(1.2, 0, 0);

		glPushMatrix(); {
			glColor3f(0.38, 0.38, 0.38);

			if (walking) {
				glTranslatef(0, 0, 1);
				glRotatef(rightWalkingHipsAndThighAngle, 1, 0, 0);
				glTranslatef(0, 0, -1);
			}

			if (running) {
				glTranslatef(0, 0, 1.5);
				glRotatef(rightRunningHipsAndThighAngle, 1, 0, 0);
				glTranslatef(0, 0, -1.5);
			}

			if (flying) {
				glTranslatef(0, 0, 1);
				glRotatef(-flyingHipsAndThighAngle, 1, 0, 0);
				glTranslatef(0, 0, -1);
			}

			glPushMatrix(); {
				//ball joint -- hips to thigh 
				glPushMatrix(); {
					glTranslatef(-0.3, 0.4, 1.5);
					drawJointHipsToThigh();
				} glPopMatrix();

				//thigh 
				glPushMatrix(); {
					glTranslatef(-0.3, 0.4, -1.8);
					drawThigh();
					glColor3f(0.38, 0.38, 0.38);

					//draw Thigh Armor
					glPushMatrix(); {
						glTranslatef(-0.4f, 0.1f, 1.5f);
						glRotatef(90, 1, 0, 0);
						glRotatef(-90, 0, 1, 0);
						glScalef(5, 8, 4);
						drawArmorPlate();
					}glPopMatrix();

					glPushMatrix(); {
						glTranslatef(0.4f, 0.1f, 1.5f);
						glRotatef(90, 1, 0, 0);
						glRotatef(80, 0, 1, 0);
						glScalef(5, 8, 4);
						drawArmorPlate();
					}glPopMatrix();

					glPushMatrix(); {
						glTranslatef(0, -0.5f, 1.5f);
						glRotatef(90, 1, 0, 0);
						glScalef(4, 8, 4);
						drawArmorPlate();
					}glPopMatrix();

					//tied gold rope #1
					glPushMatrix(); {
						glScalef(1.8, 2, 2);
						glRotatef(-90, 0, 1, 0);
						glTranslatef(1.7f, -0.25, -0.28f);
						glPushMatrix(); {
							//front
							glTranslatef(-0.6f, 0.55f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, -0.05f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//back
							glTranslatef(-0.6f, -0.1f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, 0.57f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();
					}glPopMatrix();


					//tied gold rope #2
					glPushMatrix(); {
						glScalef(1.8, 2, 2);
						glRotatef(-90, 0, 1, 0);
						glTranslatef(1.5f, -0.25, -0.28f);
						glPushMatrix(); {
							//front
							glTranslatef(-0.6f, 0.55f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, -0.05f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//back
							glTranslatef(-0.6f, -0.1f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, 0.57f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();
					}glPopMatrix();

				} glPopMatrix();
			}glPopMatrix();


			//ball joint -- thigh to calf 
			glPushMatrix(); {
				glTranslatef(-0.3, 0.4, -2.1);
				if (walking) {
					glRotatef(rightWalkingThighAndCalfAngle, 1, 0, 0);
				}
				if (running) {
					glRotatef(rightRunningThighAndCalfAngle, 1, 0, 0);
				}
				if (flying) {
					glRotatef(flyingThighAndCalfAngle, 1, 0, 0);
				}
				drawJointThighToCalf();
				glColor3f(0.38, 0.38, 0.38);
				//	drawKneeArmor();

					//calf 
				glPushMatrix(); {
					glTranslatef(0, 0, -2.5);
					drawCalf();
					glColor3f(0.38, 0.38, 0.38);
					//drawCalfArmor

					glPushMatrix(); {
						glTranslatef(-0.35f, 0.1f, 1.2f);
						glRotatef(90, 1, 0, 0);
						glRotatef(-80, 0, 1, 0);
						glRotatef(3, 1, 0, 0);
						glScalef(4, 5, 4);
						drawArmorPlate();
					}glPopMatrix();

					glPushMatrix(); {
						glTranslatef(0, -0.35f, 1.2f);
						glRotatef(93, 1, 0, 0);
						glScalef(3, 5, 4);
						drawArmorPlate();
					}glPopMatrix();


					glPushMatrix(); {
						glTranslatef(0.35f, 0.1f, 1.2f);
						glRotatef(90, 1, 0, 0);
						glRotatef(80, 0, 1, 0);
						glRotatef(3, 1, 0, 0);
						glScalef(4, 5, 4);
						drawArmorPlate();
					}glPopMatrix();

					//tied gold rope #1
					glPushMatrix(); {
						glScalef(1.5, 1.6, 1.6);
						glRotatef(-90, 0, 1, 0);
						glTranslatef(0.8f, -0.24, -0.28f);
						glPushMatrix(); {
							//front
							glTranslatef(-0.6f, 0.55f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, -0.05f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//back
							glTranslatef(-0.6f, -0.1f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, 0.57f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();
					}glPopMatrix();

					//tied gold rope #2
					glPushMatrix(); {
						glScalef(1.5, 1.6, 1.6);
						glRotatef(-90, 0, 1, 0);
						glTranslatef(0.9f, -0.24, -0.28f);
						glPushMatrix(); {
							//front
							glTranslatef(-0.6f, 0.55f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, -0.05f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//back
							glTranslatef(-0.6f, -0.1f, -0.05f);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();

						glPushMatrix(); {
							//side
							glTranslatef(-0.6f, 0.55f, 0.57f);
							glRotatef(90, 1, 0, 0);
							drawCylinder(0.02f, 0.02f, 0.65f, GL_FILL);
						}glPopMatrix();
					}glPopMatrix();

				}glPopMatrix();

				//square joint -- calf to foot 
				glPushMatrix(); {
					glTranslatef(-0.25, -0.2, -3.0);
					drawJointCalfToFoot();
				} glPopMatrix();

				//foot 
				glPushMatrix(); {
					glTranslatef(0, -0.22, -3.2);
					drawFootL();
					//	glColor3f(0.38, 0.38, 0.38);
					drawFootArmor();
				} glPopMatrix();

			} glPopMatrix();
		}glPopMatrix();
	} glPopMatrix();
}
void drawJointHipsToThigh() {
	glPushAttrib(1);
	glColor3f(0, 0, 0);
	drawFillSphere(0.4);
	glPopAttrib();

}
void drawThigh() {
	glPushAttrib(1);
	//grey bar
	glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
	//drawFillCylinder(0.3, 0.3, 3);
	drawFillCylinder(0.4, 0.5, 3, 1);
	glPopAttrib();
}
void drawJointThighToCalf() {
	glPushAttrib(1);
	glColor3f(0, 0, 0);
	drawFillSphere(0.3);
	glPopAttrib();
}
void drawCalf() {
	glPushAttrib(1);
	//grey bar
	glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
	drawFillCylinder(0.3, 0.4, 2.3, 1);
	glPopAttrib();
}
void drawJointCalfToFoot() {
	glPushAttrib(1);
	glColor3f(0, 0, 0);
	drawCuboid(0.5, 0.5, 0.5);
	glPopAttrib();
}
void drawFootR() {
	glPushAttrib(1);
	//grey bar
	glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
	glPushMatrix(); {
		glRotatef(180, 1, 0, 0);
		glRotatef(90, 0, 0, 1);
		glPushMatrix(); {
			glTranslatef(0.0f, 0.125f, 0);
			drawRightAngleTriangle(1.2, 0.7, 0.3);
		}glPopMatrix();

		//foot
		glPushMatrix(); {
			glTranslatef(0.0f, -0.15f, 0);
			drawRightAngleTriangle(1.2, 0.7, 0.175);
		}glPopMatrix();
	} glPopMatrix();

	glPushMatrix(); {
		glRotatef(180, 1, 0, 0);
		glRotatef(-90, 0, 0, 1);
		glTranslatef(0.3f, -0.0f, 0.0);
		drawRightAngleTriangle(0.8, 0.7, 0.3);
	}glPopMatrix();
	glPopAttrib();
}
void drawFootL() {
	glPushAttrib(1);
	//grey bar
	glColor3f(65 / 255.0f, 65 / 255.0f, 65 / 255.0f);
	glPushMatrix(); {
		glRotatef(180, 1, 0, 0);
		glRotatef(90, 0, 0, 1);
		glPushMatrix(); {
			glTranslatef(0.0f, -0.15f, 0);
			drawRightAngleTriangle(1.2, 0.7, 0.3);
		}glPopMatrix();

		//foot
		glPushMatrix(); {
			glTranslatef(0.0f, 0.125f, 0);
			drawRightAngleTriangle(1.2, 0.7, 0.175);
		}glPopMatrix();
	} glPopMatrix();

	glPushMatrix(); {
		glRotatef(180, 1, 0, 0);
		glRotatef(-90, 0, 0, 1);
		glTranslatef(0.3f, -0.0f, 0.0);
		drawRightAngleTriangle(0.8, 0.7, 0.3);
	}glPopMatrix();
	glPopAttrib();
}
void drawFootArmor() {
	glPushMatrix(); {
		glScalef(0.9, 1.1, 0.9);
		glTranslatef(-0.2f, -1.3, -0.3);

		glPushAttrib(1);
		//crimson red
		glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);

		//TOES 
		glPushMatrix(); {
			glRotatef(180, 1, 0, 0);
			glRotatef(90, 0, 0, 1);
			glTranslatef(0, -0.2, 0);
			drawRightAngleTriangle(0.1, 0.2, 0.4);
		}glPopMatrix();

		//2nd part foot -- after toes 
		glPushMatrix(); {
			glPushMatrix(); {
				drawCuboid(0.4, 0.4, 0.3);
			}glPopMatrix();
			glPushMatrix(); {
				glRotatef(180, 0, 0, 1);
				glRotatef(90, 1, 0, 0);
				glTranslatef(0, 0.15, 0.4);
				drawRightAngleTriangle(0.2, 0.4, 0.3);
			}glPopMatrix();		//LEFT TRIANGLE 
			glPushMatrix(); {
				glRotatef(180, 0, 1, 0);
				glTranslatef(-0.4, 0, -0.3);
				glPushMatrix(); {
					glRotatef(180, 0, 0, 1);
					glRotatef(90, 1, 0, 0);
					glTranslatef(0, 0.15, 0.4);
					drawRightAngleTriangle(0.2, 0.4, 0.3);
				}glPopMatrix();
			}glPopMatrix();		//RIGHT TRIANGLE
		}glPopMatrix();
		glPopAttrib();

		glPushAttrib(1);
		//crimson red
		glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
		//3rd PART 
		glPushMatrix(); {
			glTranslatef(0, 0.03, 0);
			glPushMatrix(); {
				glTranslatef(-0.2, 0.4, 0);
				drawCuboid(0.8, 0.6, 0.3);
			}glPopMatrix();
			glPushMatrix(); {
				glTranslatef(-0.2, 0.6, 0);
				glRotatef(180, 0, 0, 1);
				glRotatef(90, 1, 0, 0);
				glTranslatef(0, 0.15, 0.4);
				drawRightAngleTriangle(0.1, 0.6, 0.3);
			}glPopMatrix();		//LEFT TRIANGLE 
			glPushMatrix(); {
				glRotatef(180, 0, 1, 0);
				glTranslatef(-0.4, 0, -0.3);
				glPushMatrix(); {
					glTranslatef(-0.2, 0.6, 0);
					glRotatef(180, 0, 0, 1);
					glRotatef(90, 1, 0, 0);
					glTranslatef(0, 0.15, 0.4);
					drawRightAngleTriangle(0.1, 0.6, 0.3);
				}glPopMatrix();
			}glPopMatrix();
		}glPopMatrix();		//RIGHT TRIANGLE 

		//4th PART 
		glPushMatrix(); {
			glTranslatef(-0.3, 1.1, 0);
			drawCuboid(1, 0.4, 0.3);
		}glPopMatrix();
		glPopAttrib();

		glPushAttrib(1);
		//crimson red
		glColor3f(153 / 255.0f, 0 / 255.0f, 0 / 255.0f);
		//5th PART 
		glPushMatrix(); {
			glRotatef(180, 1, 0, 0);
			glTranslatef(0, -2.5, -0.3);
			//3rd PART 
			glPushMatrix(); {
				glTranslatef(0, 0.03, 0);
				glPushMatrix(); {
					glTranslatef(-0.2, 0.4, 0);
					drawCuboid(0.8, 0.5, 0.3);
				}glPopMatrix();
				glPushMatrix(); {
					glTranslatef(-0.2, 0.5, 0);
					glRotatef(180, 0, 0, 1);
					glRotatef(90, 1, 0, 0);
					glTranslatef(0, 0.15, 0.4);
					drawRightAngleTriangle(0.1, 0.5, 0.3);
				}glPopMatrix();		//LEFT TRIANGLE 
				glPushMatrix(); {
					glRotatef(180, 0, 1, 0);
					glTranslatef(-0.4, 0, -0.3);
					glPushMatrix(); {
						glTranslatef(-0.2, 0.5, 0);
						glRotatef(180, 0, 0, 1);
						glRotatef(90, 1, 0, 0);
						glTranslatef(0, 0.15, 0.4);
						drawRightAngleTriangle(0.1, 0.5, 0.3);
					}glPopMatrix();
				}glPopMatrix();
			}glPopMatrix();		//RIGHT TRIANGLE 
		}glPopMatrix();

		//6th PART 
		glPushMatrix(); {
			glRotatef(180, 1, 0, 0);
			glTranslatef(0, -2.5, -0.3);
			//2nd part foot -- after toes 
			glPushMatrix(); {
				glTranslatef(0, 0.1, 0);
				drawCuboid(0.4, 0.3, 0.3);
			}glPopMatrix();
			glPushMatrix(); {
				glRotatef(180, 0, 0, 1);
				glRotatef(90, 1, 0, 0);
				glTranslatef(0, 0.15, 0.4);
				drawRightAngleTriangle(0.2, 0.3, 0.3);
			}glPopMatrix();		//LEFT TRIANGLE 
			glPushMatrix(); {
				glRotatef(180, 0, 1, 0);
				glTranslatef(-0.4, 0, -0.3);
				glPushMatrix(); {
					glRotatef(180, 0, 0, 1);
					glRotatef(90, 1, 0, 0);
					glTranslatef(0, 0.15, 0.4);
					drawRightAngleTriangle(0.2, 0.3, 0.3);
				}glPopMatrix();
			}glPopMatrix();		//RIGHT TRIANGLE
		}glPopMatrix();
		glPopAttrib();

		//fire
		glPushMatrix(); {
			glTranslatef(0.2, 1.6, 0.05);		//x +ve to right, z +ve to back, y +ve to up 
			drawFireUnderFoot();
		}glPopMatrix();
	}glPopMatrix();
}
void drawFireUnderFoot() {
	glPushMatrix(); {
		if (flying) {
			fire();
		}

		glPushMatrix(); {
			drawFillCylinder(0.3, 0.3, flyingCylinderHeight, 1);
		}glPopMatrix();		//CYLINDER

		glPushMatrix(); {
			glRotatef(180, 1, 0, 0);
			drawFillCylinder(0.3, 0, flyingFireHeight, 2);
		}glPopMatrix();		//FIRE 
	}glPopMatrix();
}
//-----------------------DISPLAY----------------------------------
void display() {
	glMatrixMode(GL_MODELVIEW);
	glClearColor(159 / 255.0f, 159 / 255.0f, 159 / 255.0f, 0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	GLUquadricObj* object = gluNewQuadric();

	glLoadIdentity();
	glTranslatef(0.0, 0.0, zoomLevel);
	if (zoomLevel <= -14) {
		zoomLevel = -14;
	}
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(xRotated, 1.0, 0.0, 0.0);
	glRotatef(yRotated, 0.0, 1.0, 0.0);
	glRotatef(zRotated, 0.0, 0.0, 1.0);

	if (!textureOn) {
		glEnable(GL_TEXTURE_2D);
	}
	else if (textureOn) {
		glDisable(GL_TEXTURE_2D);
	}
	if (!lightOn) {
		glEnable(GL_LIGHTING);

	}
	else if (lightOn)
	{
		glDisable(GL_LIGHTING);

	}

	GLfloat low_shininess[] = { 5.0f, 5.0f, 5.0f, 0.0f };
	GLfloat high_shininess[] = { 100.0f, 100.0f, 100.0f, 100.0f };
	GLfloat mat_emission[] = { 0.5f, 0.5f, 0.5f, 0.0f };

	//gluQuadricNormals(object, GLU_SMOOTH);
	gluQuadricTexture(object, GL_TRUE);

	//robot
	glPushMatrix(); {
		if (walking) {
			walkingFront();
		}
		if (running) {
			runningFront();
		}
		if (flying) {
			fly();
		}
		//glScalef(0.7, 0.7, 0.7);
		glTranslatef(0, 1.0f, -0.3f);
		//robot
		drawCyberBot(object);

		//draw laser weapon
		glPushMatrix(); {
			glScalef(0.2, 0.2, 0.2);
			glTranslatef(0.7f, 2.4f, 1.2f);
			glRotatef(180, 0, 0, 1);
			glRotatef(-90, 1, 0, 0);
			drawLaserWeapon(object);
		}glPopMatrix();

		//draw katana weapon
		glPushMatrix(); {
			glScalef(0.4, 0.4, 0.4);
			drawKatanaWeapon(object);

		}glPopMatrix();

	}glPopMatrix();

	if (dayOff == true) {
		if (dayOn == true) {
			//environment
			glPushMatrix(); {
				glScalef(0.3, 0.3, 0.3);
				glTranslatef(-15.0f, 0.8f, 14.0f);
				drawSM(object);
			}glPopMatrix();
			drawSea(object);
			drawSky(object);
		}
		else if (dayOn == false) {
			//environment
			glPushMatrix(); {
				glScalef(0.3, 0.3, 0.3);
				glTranslatef(-15.0f, 0.8f, 14.0f);
				drawSM(object);
			}glPopMatrix();
			drawSea(object);
			drawSky(object);
		}
	}
	//ligting
	lighting();
	glFlush();
	gluDeleteQuadric(object);
}
//----------------------LIGHTING--------------------------------------
void lighting() {

	//Open and close light
	if (!isLighting) {
		glDisable(GL_LIGHTING);
	}
	else {
		glEnable(GL_LIGHTING);
		glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuseLight);
		glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLight);
		glLightfv(GL_LIGHT1, GL_POSITION, positionLight);
		glEnable(GL_LIGHT1);
	}
}
void redMaterial() {
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, red);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuseLight);
}
void whiteMaterial() {
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambientLight);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuseLight);
}
void grayMaterial() {
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, gray);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuseLight);
}
void goldMaterial() {
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, gold);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuseLight);
}
//------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow)
{
	WNDCLASSEX wc;
	ZeroMemory(&wc, sizeof(WNDCLASSEX));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hInstance = GetModuleHandle(NULL);
	wc.lpfnWndProc = WindowProcedure;
	wc.lpszClassName = WINDOW_TITLE;
	wc.style = CS_HREDRAW | CS_VREDRAW;
	if (!RegisterClassEx(&wc)) return false;
	HWND hWnd = CreateWindow(WINDOW_TITLE, WINDOW_TITLE, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, 1080, 1080,
		NULL, NULL, wc.hInstance, NULL);

	//--------------------------------
	//	Initialize window for OpenGL
	//--------------------------------

	HDC hdc = GetDC(hWnd);

	//	initialize pixel format for the window
	initPixelFormat(hdc);

	//	get an openGL context
	HGLRC hglrc = wglCreateContext(hdc);

	//	make context current
	if (!wglMakeCurrent(hdc, hglrc)) return false;

	//--------------------------------
	//	End initialization
	//--------------------------------
	ShowWindow(hWnd, nCmdShow);
	MSG msg;
	ZeroMemory(&msg, sizeof(msg));

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(70.0, 1.0, 1.0, 30.0);

	glEnable(GL_DEPTH_TEST);
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/armorPlateTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &armorPlateTextures);
		glBindTexture(GL_TEXTURE_2D, armorPlateTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/armorPlateSideTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &armorPlateSideTextures);
		glBindTexture(GL_TEXTURE_2D, armorPlateSideTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/katanaBladeTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &katanaBladeTextures);
		glBindTexture(GL_TEXTURE_2D, katanaBladeTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/armorBodyTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &BodyTextures);
		glBindTexture(GL_TEXTURE_2D, BodyTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/whiteMetal.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &whiteMetalTextures);
		glBindTexture(GL_TEXTURE_2D, whiteMetalTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/goldMetal.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &goldMetalTextures);
		glBindTexture(GL_TEXTURE_2D, goldMetalTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/blackMetalTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &blackMetalTextures);
		glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/blackMetalTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &blackMetalTextures);
		glBindTexture(GL_TEXTURE_2D, blackMetalTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/grayMetalTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &grayMetalTextures);
		glBindTexture(GL_TEXTURE_2D, grayMetalTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/umbrella.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &umbrellaTextures);
		glBindTexture(GL_TEXTURE_2D, umbrellaTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/whiteTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &whiteTextures);
		glBindTexture(GL_TEXTURE_2D, whiteTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}

	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/flameTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);
		glGenTextures(1, &flameTextures);
		glBindTexture(GL_TEXTURE_2D, flameTextures);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //smooth effect
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);

	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/moonTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);

		glGenTextures(1, &moonTextures);
		glBindTexture(GL_TEXTURE_2D, moonTextures);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/seaTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);

		glGenTextures(1, &seaTextures);
		glBindTexture(GL_TEXTURE_2D, seaTextures);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/skyTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);

		glGenTextures(1, &skyTextures);
		glBindTexture(GL_TEXTURE_2D, skyTextures);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/nightSeaTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);

		glGenTextures(1, &nightSeaTextures);
		glBindTexture(GL_TEXTURE_2D, nightSeaTextures);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/nightSkyTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);

		glGenTextures(1, &nightSkyTextures);
		glBindTexture(GL_TEXTURE_2D, nightSkyTextures);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}
	{
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		HBITMAP hBMP = (HBITMAP)LoadImage(GetModuleHandle(NULL),
			"texture/sunTexture.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION |
			LR_LOADFROMFILE);
		GetObject(hBMP, sizeof(BMP), &BMP);

		glGenTextures(1, &sunTextures);
		glBindTexture(GL_TEXTURE_2D, sunTextures);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, BMP.bmWidth, BMP.bmHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, BMP.bmBits);
	}

	while (true)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT) break;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		display();
		SwapBuffers(hdc);
	}

	glDeleteTextures(1, &armorPlateTextures);
	glDeleteTextures(1, &armorPlateSideTextures);
	glDeleteTextures(1, &katanaBladeTextures);
	glDeleteTextures(1, &BodyTextures);
	glDeleteTextures(1, &whiteMetalTextures);
	glDeleteTextures(1, &goldMetalTextures);
	glDeleteTextures(1, &blackMetalTextures);
	glDeleteTextures(1, &grayMetalTextures);
	glDeleteTextures(1, &umbrellaTextures);
	glDeleteTextures(1, &whiteTextures);
	glDeleteTextures(1, &flameTextures);
	glDeleteTextures(1, &moonTextures);
	glDeleteTextures(1, &seaTextures);
	glDeleteTextures(1, &skyTextures);
	DeleteObject(hBMP);

	UnregisterClass(WINDOW_TITLE, wc.hInstance);
	return true;
}
//--------------------------------------------------------------------